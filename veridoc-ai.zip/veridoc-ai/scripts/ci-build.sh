#!/usr/bin/env bash
# GitHub Actions'ta APK derleme adımları. İş akışı dosyası bu betiği çağırır;
# böylece sonraki değişiklikler yalnızca zip ile gelir.
set -euo pipefail

if [ -f tests/test_analyzer.js ]; then node tests/test_analyzer.js; fi

npm install --no-audit --no-fund

rm -rf android
npx cap add android
npx capacitor-assets generate --android
node scripts/patch-android.js
npx cap sync android

cd android
chmod +x gradlew
./gradlew assembleDebug --no-daemon
cp app/build/outputs/apk/debug/app-debug.apk ../VeriDoc-AI.apk
echo "APK hazır: VeriDoc-AI.apk"
