// GitHub Actions'ta "npx cap add android" sonrası Android projesini ayarlar.
const fs = require('fs');
const path = require('path');
const res = p => path.join(__dirname, '..', 'android', 'app', 'src', 'main', p);

// 1) Manifest: isteğe bağlı yerel ağ sunucusu (http) için açık metin trafiğe izin
const mf = res('AndroidManifest.xml');
let m = fs.readFileSync(mf, 'utf8');
if (!m.includes('usesCleartextTraffic')) m = m.replace('<application', '<application\n        android:usesCleartextTraffic="true"');
fs.writeFileSync(mf, m);

// 2) Android 15 kenardan kenara zorlamasını kapat (üst çubuk içeriği örtmesin)
const st = res('res/values/styles.xml');
let s = fs.readFileSync(st, 'utf8');
if (!s.includes('windowOptOutEdgeToEdgeEnforcement')) {
  s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowOptOutEdgeToEdgeEnforcement" tools:targetApi="35">true</item>');
  if (!s.includes('xmlns:tools')) s = s.replace('<resources>', '<resources xmlns:tools="http://schemas.android.com/tools">');
}
fs.writeFileSync(st, s);

// 3) Uygulama adı
const sx = res('res/values/strings.xml');
let x = fs.readFileSync(sx, 'utf8');
x = x.replace(/<string name="app_name">.*?<\/string>/, '<string name="app_name">VeriDoc AI</string>')
     .replace(/<string name="title_activity_main">.*?<\/string>/, '<string name="title_activity_main">VeriDoc AI</string>');
fs.writeFileSync(sx, x);
console.log('Android projesi ayarlandı.');
