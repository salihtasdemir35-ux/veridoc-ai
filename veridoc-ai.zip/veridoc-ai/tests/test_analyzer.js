// Çalıştırma: node tests/test_analyzer.js
const assert = require('assert');
const A = require('../frontend/js/analyzer.js');
const C = require('../frontend/js/citations.js');

const human = 'Bu çalışmada 2019-2021 yılları arasında Ankara ve Konya illerindeki 14 ortaokulda 312 öğrenciyle görüştük. ' +
  'Görüşmelerin 47’si ses kaydına alınamadı; bu yüzden analizde yalnızca notlar kullanıldı. Yılmaz (2018), benzer bir örneklemde ' +
  'okuma kaygısının cinsiyete göre değişmediğini bildirmişti, oysa bizim verilerimizde kız öğrencilerin ortalaması 3,4 iken erkeklerde 2,9 çıktı. ' +
  'Bu farkı açıklamak kolay değil. Sahada gözlemledik ki öğretmenlerin bir kısmı sınavdan önce ek etüt yapıyordu (Demir vd., 2020). ' +
  'Konya’daki iki okulda ise etüt hiç yoktu ve fark neredeyse kayboldu.';
const ai = 'Günümüzde eğitim teknolojileri öğrenme süreçlerinde önemli bir rol oynamaktadır. Ayrıca dijital araçlar öğrencilerin motivasyonunu artırmada kritik bir rol üstlenmektedir. ' +
  'Bununla birlikte öğretmenlerin bu araçları etkili bir şekilde kullanması büyük önem taşımaktadır. Bu bağlamda kapsamlı bir şekilde planlanmış eğitim programları gereklidir. ' +
  'Sonuç olarak teknoloji entegrasyonu çok boyutlu bir yaklaşım gerektirmektedir. Dolayısıyla tüm paydaşların sürece katılımı sağlanmalıdır.';
const doc = {
  fileName: 'test.docx', pageCount: 2, pageApprox: true,
  paragraphs: [
    { id: 'p1', kind: 'heading', text: '1. Giriş', page: 1 },
    { id: 'p2', kind: 'para', text: ai, page: 1 },
    { id: 'p3', kind: 'heading', text: 'Bulgular', page: 1 },
    { id: 'p4', kind: 'para', text: human, page: 1 },
    { id: 'p5', kind: 'para', text: 'Kısa bir not.', page: 2 },
    { id: 'p6', kind: 'heading', text: 'Kaynakça', page: 2 },
    { id: 'p7', kind: 'para', text: 'Yılmaz, A. (2018). Okuma kaygısı ve cinsiyet. Eğitim Dergisi, 12(3), 45-60. https://doi.org/10.1234/abcd.5678.', page: 2 },
    { id: 'p8', kind: 'para', text: 'Kaya, B. (2015). Hiç atıf yapılmayan bir kaynak. Ankara: Yayınevi.', page: 2 }
  ]
};

const s = A.splitSentences('Yılmaz vd. (2020) bunu gösterdi. İkinci cümle burada. Prof. Dr. A. Kaya da katıldı.');
assert.strictEqual(s.length, 3, 'cümle bölme: ' + JSON.stringify(s));
assert.strictEqual(A.sectionOf('2.1. Yöntem'), 'yontem');
assert.strictEqual(A.sectionOf('Sonuç olarak bu çalışma çok önemli bir katkı sunuyor ve devam ediyor'), null);
assert.strictEqual(A.detectLang(ai), 'tr');

const r = A.analyzeDocument(doc);
const pAI = r.paragraphs.find(p => p.id === 'p2'), pH = r.paragraphs.find(p => p.id === 'p4'), pS = r.paragraphs.find(p => p.id === 'p5');
console.log('AI-benzeri paragraf:', pAI.combined, pAI.categoryLabel, '| insan paragrafı:', pH.combined, pH.categoryLabel, '| kısa:', pS.categoryLabel);
assert(pAI.combined > pH.combined + 25, 'AI-benzeri paragraf daha yüksek puan almalı');
assert.strictEqual(pAI.section, 'giris'); assert.strictEqual(pH.section, 'bulgular');
assert.strictEqual(pS.category, 5, 'kısa paragraf sonuçlandırılmamalı');
assert.strictEqual(r.references.length, 2);
assert(r.summary.overall >= 0 && r.summary.overall <= 100);
assert.strictEqual(r.summary.hasModel, false, 'model yokken model katmanı görünmemeli');

// Model katmanı uygulama
A.applyModel(r, { p2: { ai_score: 0.9, calibrated: true }, p4: { ai_score: 0.1, calibrated: true } });
assert.strictEqual(r.summary.hasModel, true);
assert.strictEqual(pAI.combined, Math.round(0.5 * pAI.layers.heuristic.score + 45));

const c = C.analyze(r);
console.log('Atıf:', c.inText, 'eşleşmeyen:', c.unmatchedInText.map(x => x.raw), 'atıfsız kaynak:', c.uncitedRefs.length);
assert.strictEqual(c.references.length, 2);
assert.strictEqual(c.references[0].doi, '10.1234/abcd.5678');
assert(c.unmatchedInText.some(u => u.surname === 'Demir'), 'Demir kaynakçada yok, işaretlenmeli');
assert.strictEqual(c.uncitedRefs.length, 1);
assert(A.expertReport(r, c).length >= 6);

// İngilizce
const en = A.paragraphFeatures('It is important to note that technology plays a crucial role in education. Furthermore, it fosters a holistic learning landscape. Moreover, teachers must navigate the complexities of this ever-evolving field.', 'en');
assert(en.phraseHits.length >= 4, 'İngilizce kalıp ifadeler: ' + en.phraseHits.map(x => x.text));
console.log('TÜM TESTLER GEÇTİ');
