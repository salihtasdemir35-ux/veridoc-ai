#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "VeriDoc AI başlatılıyor..."
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
python -m pip install -q --upgrade pip
python -m pip install -q -r backend/requirements.txt
( sleep 3; (xdg-open http://localhost:8000 || open http://localhost:8000) >/dev/null 2>&1 ) &
cd backend
python -m uvicorn main:app --host 127.0.0.1 --port 8000
