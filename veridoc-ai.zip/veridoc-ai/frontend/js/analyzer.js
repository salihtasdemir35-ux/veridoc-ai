/*
 * VERIDOC AI — Analiz Motoru (Katman 1 + Katman 2 + birleştirme)
 * Tarayıcıda ve Node.js'te çalışır. Hiçbir veri dışarı gönderilmez.
 *
 * ÖNEMLİ: Bu dosyadaki puanlar SEZGİSEL (heuristik) ve KALİBRE EDİLMEMİŞTİR.
 * Bir olasılık değil, "AI yazım karakteristikleriyle örtüşme göstergesi"dir.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.AADAnalyzer = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const VERSION = '1.0.0';

  // ---------------------------------------------------------------- Sözlükler
  const LISTS = {
    tr: {
      stop: ['ve', 'bir', 'bu', 'da', 'de', 'ile', 'için', 'olarak', 'olan', 'gibi', 'daha', 'çok', 'en', 'ise', 'ki', 'ne',
        'o', 'şu', 'her', 'kadar', 'sonra', 'önce', 'ancak', 'fakat', 'ama', 'veya', 'ya', 'hem', 'değil', 'mı', 'mi',
        'üzerinde', 'arasında', 'tarafından', 'göre', 'karşı', 'kendi', 'diğer', 'aynı', 'ilgili', 'yönelik', 'olduğu',
        'olduğunu', 'olmak', 'olup', 'şekilde', 'bunun', 'buna', 'bu', 'ayrıca', 'gibi', 'ise', 'yani', 'çünkü', 'eğer',
        'hangi', 'nasıl', 'neden', 'tüm', 'bazı', 'birçok', 'söz', 'konusu', 'olan', 'oldukça', 'üzere'],
      connectors: ['ayrıca', 'bununla birlikte', 'buna ek olarak', 'ek olarak', 'sonuç olarak', 'dolayısıyla', 'öte yandan',
        'bu nedenle', 'bu bağlamda', 'nitekim', 'genel olarak', 'bunun yanı sıra', 'aynı zamanda', 'diğer taraftan',
        'son olarak', 'öncelikle', 'böylece', 'kısacası', 'bununla beraber', 'özetle', 'bu doğrultuda', 'bu çerçevede',
        'buna karşın', 'bunun sonucunda', 'sonuçta'],
      phrases: ['önemli bir rol oynamaktadır', 'önemli bir rol oynar', 'kritik bir rol oynamaktadır', 'kritik bir rol',
        'büyük önem taşımaktadır', 'büyük önem taşır', 'göz önünde bulundurulduğunda', 'çok yönlü', 'kapsamlı bir şekilde',
        'derinlemesine', 'bütüncül bir yaklaşım', 'dikkate değer', 'önemli bir yere sahiptir', 'vazgeçilmez bir',
        'ışık tutmaktadır', 'ışık tutmayı amaçlamaktadır', 'katkı sağlamaktadır', 'hayati önem', 'günümüzde',
        'sürekli değişen', 'hızla gelişen', 'altını çizmektedir', 'yeni ufuklar', 'potansiyelini ortaya koymaktadır',
        'önemli bir adım', 'çeşitli faktörler', 'çok boyutlu', 'önemli katkılar sunmaktadır', 'kilit bir rol',
        'temel taşı', 'ayrılmaz bir parçası', 'giderek artan', 'dinamik bir', 'derin bir anlayış', 'etkili bir şekilde',
        'önemli ölçüde katkı', 'değerli içgörüler', 'paradigma değişimi', 'yol açmaktadır'],
      firstPerson: ['bence', 'kanımca', 'düşünüyorum', 'gözlemledim', 'gözlemledik', 'yaptık', 'yaptım', 'topladık',
        'görüştük', 'bulduk', 'tespit ettik', 'çalışmamızda', 'araştırmamızda', 'ölçtük', 'uyguladık', 'gördük',
        'kanaatimizce', 'deneyimlerime göre', 'sahada', 'katılımcılarımız']
    },
    en: {
      stop: ['the', 'of', 'and', 'a', 'an', 'in', 'to', 'is', 'are', 'was', 'were', 'for', 'on', 'with', 'as', 'by', 'that',
        'this', 'these', 'those', 'it', 'its', 'be', 'been', 'from', 'at', 'or', 'not', 'but', 'which', 'their', 'has',
        'have', 'had', 'can', 'may', 'also', 'such', 'than', 'more', 'most', 'into', 'between', 'we', 'our', 'they',
        'there', 'other', 'both', 'each', 'all', 'some', 'when', 'while', 'where', 'how', 'what', 'who', 'would', 'could'],
      connectors: ['furthermore', 'moreover', 'additionally', 'in addition', 'however', 'therefore', 'thus',
        'consequently', 'in conclusion', 'overall', 'notably', 'in summary', 'as a result', 'on the other hand',
        'similarly', 'ultimately', 'importantly', 'hence', 'finally', 'nevertheless', 'nonetheless', 'accordingly'],
      phrases: ['delve', 'delves', 'delving', 'it is important to note', 'it is worth noting', 'plays a crucial role',
        'plays a pivotal role', 'plays a vital role', 'crucial role', 'pivotal', 'multifaceted', 'tapestry',
        'underscore', 'underscores', 'underscoring', "in today's", 'rapidly evolving', 'ever-evolving', 'landscape',
        'foster', 'fostering', 'holistic', 'navigate the complexities', 'shed light', 'sheds light', 'a testament to',
        'intricate', 'paving the way', 'in the realm of', 'realm', 'leverage', 'leveraging', 'seamless', 'seamlessly',
        'valuable insights', 'key insights', 'not only', 'a myriad of', 'nuanced understanding', 'comprehensive understanding',
        'harness the power', 'game-changer', 'cutting-edge', 'embark', 'unwavering', 'meticulous', 'meticulously'],
      firstPerson: ['we found', 'we observed', 'we collected', 'we measured', 'in our study', 'our results', 'we conducted',
        'i argue', 'we interviewed', 'we recruited', 'in my experience', 'we noticed', 'we coded', 'our fieldwork']
    }
  };

  const SECTION_PATTERNS = [
    ['ozet', ['özet', 'öz', 'abstract', 'summary', 'extended abstract', 'genişletilmiş özet']],
    ['giris', ['giriş', 'introduction']],
    ['literatur', ['literatür', 'literatür taraması', 'kuramsal çerçeve', 'kavramsal çerçeve', 'literature', 'literature review',
      'related work', 'theoretical framework', 'background', 'alanyazın', 'ilgili çalışmalar', 'kuramsal arka plan']],
    ['yontem', ['yöntem', 'metodoloji', 'materyal ve yöntem', 'gereç ve yöntem', 'method', 'methods', 'methodology',
      'materials and methods', 'araştırma yöntemi', 'research design', 'araştırmanın yöntemi']],
    ['bulgular', ['bulgular', 'results', 'findings', 'bulgular ve yorum']],
    ['tartisma', ['tartışma', 'discussion', 'tartışma ve sonuç', 'results and discussion']],
    ['sonuc', ['sonuç', 'sonuçlar', 'conclusion', 'conclusions', 'sonuç ve öneriler', 'öneriler', 'concluding remarks']],
    ['kaynakca', ['kaynakça', 'kaynaklar', 'references', 'bibliography', 'works cited', 'yararlanılan kaynaklar']]
  ];
  const SECTION_LABELS = {
    ozet: 'Özet', giris: 'Giriş', literatur: 'Literatür / Kuramsal çerçeve', yontem: 'Yöntem', bulgular: 'Bulgular',
    tartisma: 'Tartışma', sonuc: 'Sonuç', kaynakca: 'Kaynakça', diger: 'Diğer / Başlıksız'
  };

  const CATS = {
    1: { key: 'human', label: 'İnsan ağırlıklı yazım', color: 'green' },
    2: { key: 'edited', label: 'İnsan yazımı + AI ile dil düzenlemesi göstergeleri', color: 'orange' },
    3: { key: 'mixed', label: 'İnsan ve AI ortak üretimi (karma göstergeler)', color: 'orange' },
    4: { key: 'ai', label: 'AI üretimiyle uyumlu güçlü göstergeler', color: 'red' },
    5: { key: 'inconclusive', label: 'Sonuçlandırılamayan / belirsiz', color: 'yellow' }
  };

  // Katman 1 sinyal ağırlıkları (açıkça raporlanır)
  const WEIGHTS = { burst: 0.25, phrase: 0.25, conn: 0.15, start: 0.10, spec: 0.25 };
  // Katman birleştirme ağırlıkları
  const COMBINE = { heuristicOnly: { heuristic: 1.0 }, withModel: { heuristic: 0.5, model: 0.5 }, llm: 0 };

  const STYLE_KEYS = ['meanSentLen', 'sentLenCV', 'meanWordLen', 'ttr50', 'connPerSent', 'longWordRatio', 'commasPerSent',
    'specificity', 'stopRatio'];
  const STYLE_LABELS = {
    meanSentLen: 'Ortalama cümle uzunluğu', sentLenCV: 'Cümle uzunluğu değişkenliği', meanWordLen: 'Ortalama kelime uzunluğu',
    ttr50: 'Kelime çeşitliliği (TTR-50)', connPerSent: 'Bağlaç yoğunluğu', longWordRatio: 'Uzun kelime oranı',
    commasPerSent: 'Cümle başına virgül', specificity: 'Somutluk (sayı/atıf/özel ad)', stopRatio: 'İşlev kelimesi oranı'
  };

  // ---------------------------------------------------------------- Yardımcılar
  const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const byLen = list => [...new Set(list)].sort((a, b) => b.length - a.length);
  function buildRe(list) {
    return new RegExp('(?<![\\p{L}\\p{N}])(?:' + byLen(list).map(escRe).join('|') + ')(?![\\p{L}\\p{N}])', 'gu');
  }
  const RE = {};
  for (const lang of ['tr', 'en']) {
    const L = LISTS[lang];
    RE[lang] = {
      stop: new Set(L.stop),
      conn: buildRe(L.connectors),
      phrase: buildRe(L.phrases),
      fp: buildRe(L.firstPerson),
      connStart: new RegExp('^\\W*(?:' + byLen(L.connectors).map(escRe).join('|') + ')(?![\\p{L}\\p{N}])', 'u')
    };
  }
  const locale = lang => (lang === 'tr' ? 'tr-TR' : 'en-US');
  const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const mean = a => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);
  const std = a => { if (a.length < 2) return 0; const m = mean(a); return Math.sqrt(mean(a.map(x => (x - m) ** 2))); };
  const round = (x, d = 2) => (x === null || x === undefined || Number.isNaN(x) ? null : Math.round(x * 10 ** d) / 10 ** d);
  const uniq = a => [...new Set(a)];

  function lowerAligned(text, lang) {
    const l = text.toLocaleLowerCase(locale(lang));
    return { l, aligned: l.length === text.length };
  }
  function findAll(re, s) {
    const out = []; re.lastIndex = 0; let m;
    while ((m = re.exec(s))) { out.push({ start: m.index, end: m.index + m[0].length, text: m[0] }); if (!m[0].length) re.lastIndex++; }
    return out;
  }
  function tokenize(text, lang) {
    return (text.toLocaleLowerCase(locale(lang)).match(/[\p{L}\p{N}]+(?:['’][\p{L}]+)?/gu) || []);
  }
  const wordsOf = (text, lang) => tokenize(text, lang).filter(t => /\p{L}/u.test(t));
  function countWords(text) { return (text.match(/[\p{L}\p{N}]+/gu) || []).filter(t => /\p{L}/u.test(t)).length; }

  function splitSentences(text) {
    const prot = text
      .replace(/(?<![\p{L}])(vd|vb|vs|örn|bkz|Dr|Prof|Doç|Yrd|Arş|Gör|Öğr|al|e\.g|i\.e|Fig|Şek|Tab|No|Vol|pp|ss|s|ca|cf|Mr|Mrs|Ms|Ed|Eds|ed|vol|ark|St)\./gu,
        m => m.replace(/\./g, '§'))
      .replace(/(?<![\p{L}])(\p{Lu})\./gu, '$1§'); // baş harfler: A. B.
    return prot.split(/(?<=[.!?…])["”’)]?\s+(?=["“'(\[]?[\p{Lu}\p{N}])/u)
      .map(s => s.replace(/§/g, '.').trim()).filter(s => s.length > 1);
  }

  function detectLang(text) {
    const sample = text.slice(0, 20000).toLocaleLowerCase('tr-TR');
    const trChars = (sample.match(/[çğışöü]/g) || []).length;
    const toks = sample.match(/\p{L}+/gu) || [];
    let tr = 0, en = 0;
    for (const t of toks) { if (RE.tr.stop.has(t)) tr++; if (RE.en.stop.has(t)) en++; }
    return tr + trChars * 0.5 >= en ? 'tr' : 'en';
  }

  function mtldPass(tokens, thr = 0.72) {
    let factors = 0, types = new Set(), count = 0;
    for (const t of tokens) {
      count++; types.add(t);
      if (types.size / count <= thr) { factors++; types = new Set(); count = 0; }
    }
    if (count > 0) { const ttr = types.size / count; factors += (1 - ttr) / (1 - thr); }
    return factors > 0 ? tokens.length / factors : tokens.length;
  }
  const mtld = toks => (mtldPass(toks) + mtldPass([...toks].reverse())) / 2;

  function normHeading(t) {
    return t.toLocaleLowerCase('tr-TR')
      .replace(/^\s*((\d+(\.\d+)*)|([ivxlc]+)|[a-h])[\.\)\-–:]?\s+/i, '')
      .replace(/[:.\-–—]+\s*$/, '').replace(/\s+/g, ' ').trim();
  }
  function sectionOf(text) {
    if (!text || text.length > 90) return null;
    const h = normHeading(text);
    if (h.split(' ').length > 6) return null;
    let best = null, bestLen = 0;
    for (const [key, pats] of SECTION_PATTERNS) {
      for (const p of pats) {
        if (h === p || h.startsWith(p + ' ') || h.startsWith(p + ':')) {
          const extra = h.slice(p.length).trim().split(' ').filter(Boolean).length;
          if (extra <= 3 && p.length > bestLen) { best = key; bestLen = p.length; }
        }
      }
    }
    return best;
  }
  function inlineSection(text) { // "Özet: ..." / "Abstract — ..."
    const m = text.match(/^\s*(özet|abstract|öz|summary)\s*[:.\-–—]\s+/i);
    return m ? 'ozet' : null;
  }

  // ---------------------------------------------------------------- Katman 1
  function paragraphFeatures(text, lang) {
    const R = RE[lang];
    const sents = splitSentences(text);
    const toks = wordsOf(text, lang);
    const n = toks.length;
    const sentLens = sents.map(s => wordsOf(s, lang).length).filter(x => x > 0);
    const meanSentLen = mean(sentLens);
    const sentLenCV = meanSentLen ? std(sentLens) / meanSentLen : 0;
    const wl = toks.map(t => t.length);
    const content = toks.filter(t => !R.stop.has(t) && t.length > 2);
    const freq = new Map(); for (const t of content) freq.set(t, (freq.get(t) || 0) + 1);
    const repeatedWords = [...freq.entries()].filter(([, c]) => c >= 3).sort((a, b) => b[1] - a[1]);
    const repRatio = content.length ? repeatedWords.reduce((s, [, c]) => s + c, 0) / content.length : 0;
    const { l, aligned } = lowerAligned(text, lang);
    const conn = findAll(R.conn, l), phr = findAll(R.phrase, l), fp = findAll(R.fp, l);
    const starts = sents.map(s => wordsOf(s, lang).slice(0, 2).join(' '));
    const connStarts = sents.filter(s => R.connStart.test(s.toLocaleLowerCase(locale(lang)))).length;
    const numbers = (text.match(/\d+(?:[.,]\d+)?\s*%?/g) || []).length;
    const citeRe = /\([^()]*?(?:19|20)\d{2}[a-z]?[^()]*?\)|\[\d+(?:\s*[-–,]\s*\d+)*\]/g;
    const citations = (text.match(citeRe) || []).length;
    let proper = 0;
    for (const s of sents) {
      const ws = s.split(/\s+/).slice(1);
      for (const w of ws) if (/^["“(]?\p{Lu}\p{Ll}{2,}/u.test(w)) proper++;
    }
    const chars = l.replace(/\s+/g, ' ');
    const grams = []; for (let i = 0; i + 3 <= chars.length; i++) grams.push(chars.slice(i, i + 3));
    const trigramUnique = grams.length ? new Set(grams).size / grams.length : 1;
    const punctTypes = new Set(text.match(/[;:()\-–—"“”'?!\/]/g) || []).size;
    return {
      words: n,
      sentCount: sents.length,
      sentences: sents,
      sentLens,
      meanSentLen,
      sentLenCV,
      meanWordLen: mean(wl),
      wordLenSD: std(wl),
      ttr: n ? new Set(toks).size / n : 0,
      ttr50: n ? new Set(toks.slice(0, 50)).size / Math.min(n, 50) : 0,
      mtld: n >= 50 ? mtld(toks) : null,
      repRatio,
      repeatedWords: repeatedWords.slice(0, 5),
      stopRatio: n ? toks.filter(t => R.stop.has(t)).length / n : 0,
      connHits: conn, phraseHits: phr, firstPerson: fp, aligned,
      connPerSent: sents.length ? conn.length / sents.length : 0,
      connStartRatio: sents.length ? connStarts / sents.length : 0,
      startDiversity: starts.length ? new Set(starts).size / starts.length : 1,
      commasPerSent: sents.length ? (text.match(/,/g) || []).length / sents.length : 0,
      punctTypes,
      numbers, citations, properNouns: proper,
      specificity: n ? ((numbers + citations * 2 + proper) / n) * 100 : 0,
      longWordRatio: n ? toks.filter(t => t.length >= (lang === 'tr' ? 10 : 9)).length / n : 0,
      trigramUnique
    };
  }

  function heuristicScore(f) {
    const sig = {};
    if (f.sentCount >= 3) sig.burst = clamp((0.55 - f.sentLenCV) / 0.35);
    sig.phrase = clamp(((f.phraseHits.length / Math.max(1, f.words)) * 100) / 1.5);
    sig.conn = clamp((f.connPerSent - 0.15) / 0.45);
    if (f.sentCount >= 4) sig.start = clamp((0.9 - f.startDiversity) / 0.4);
    sig.spec = clamp((2.5 - f.specificity) / 2.5);
    let s = 0, w = 0;
    for (const k of Object.keys(sig)) { s += sig[k] * WEIGHTS[k]; w += WEIGHTS[k]; }
    const raw = w ? (s / w) * 100 : 50;
    const humanAdj = Math.min(15, f.firstPerson.length * 5);
    const surfaceKeys = ['burst', 'phrase', 'conn'].filter(k => sig[k] !== undefined);
    return {
      score: Math.round(clamp(raw - humanAdj, 0, 100)),
      raw: Math.round(raw),
      signals: sig,
      humanAdj,
      surface: mean(surfaceKeys.map(k => sig[k])),
      content: sig.spec
    };
  }

  function reasonsOf(f, h) {
    const ai = [], human = [], notes = [];
    const sig = h.signals;
    if (sig.burst !== undefined) {
      if (sig.burst >= 0.5) ai.push(`Cümle uzunlukları birbirine çok yakın (değişkenlik katsayısı ${f.sentLenCV.toFixed(2)}). İnsan yazımında cümle uzunlukları çoğu zaman daha dalgalıdır.`);
      else if (f.sentLenCV >= 0.55) human.push(`Cümle uzunluklarında belirgin dalgalanma var (değişkenlik katsayısı ${f.sentLenCV.toFixed(2)}).`);
    }
    if (f.phraseHits.length) ai.push(`AI metinlerinde sık görülen kalıp ifadeler: ${uniq(f.phraseHits.map(x => '“' + x.text + '”')).slice(0, 6).join(', ')}.`);
    if (sig.conn >= 0.5) ai.push(`Geçiş/bağlaç ifadesi yoğunluğu yüksek (cümle başına ${f.connPerSent.toFixed(2)}).`);
    if (f.connStartRatio >= 0.4 && f.sentCount >= 3) ai.push(`Cümlelerin %${Math.round(f.connStartRatio * 100)}'i bir geçiş ifadesiyle başlıyor.`);
    if (sig.start !== undefined && sig.start >= 0.5) ai.push(`Cümle başlangıçları tekdüze (çeşitlilik %${Math.round(f.startDiversity * 100)}).`);
    if (sig.spec >= 0.6) ai.push('Sayı, özel ad veya atıf içermeyen genel ifadeler ağırlıkta.');
    if (f.citations > 0) human.push(`${f.citations} metin içi atıf içeriyor.`);
    if (f.numbers >= 2) human.push('Somut sayısal veri içeriyor.');
    if (f.properNouns >= 3) human.push('Çok sayıda özel ad / özgül terim içeriyor.');
    if (f.firstPerson.length) human.push(`Araştırmacı deneyimi / birinci şahıs ifadeleri: ${uniq(f.firstPerson.map(x => '“' + x.text + '”')).slice(0, 4).join(', ')}.`);
    if (f.repRatio >= 0.25 && f.repeatedWords.length) notes.push(`Sık tekrarlanan içerik kelimeleri: ${f.repeatedWords.map(([w, c]) => `${w} (${c})`).join(', ')}. Tekrar, hem insan hem AI metinlerinde görülebilir.`);
    if (f.mtld !== null) notes.push(`Kelime çeşitliliği MTLD ${f.mtld.toFixed(0)}, TTR ${f.ttr.toFixed(2)}.`);
    notes.push(`Yerel tahmin edilebilirlik (benzersiz karakter 3-gram oranı): ${f.trigramUnique.toFixed(2)}. Bu bir dil modeli “perplexity” değeri değildir.`);
    return { ai, human, notes };
  }

  // ---------------------------------------------------------------- Katman 2
  function stylometry(paras) {
    const res = { byLang: {}, series: [], sectionDistances: [] };
    const groups = {};
    for (const p of paras) if (p.words >= 40) (groups[p.lang] = groups[p.lang] || []).push(p);
    for (const lang of Object.keys(groups)) {
      const g = groups[lang];
      const m = g.length;
      const mu = {}, sd = {};
      for (const k of STYLE_KEYS) { const v = g.map(p => p.features[k]); mu[k] = mean(v); sd[k] = std(v) || 1e-6; }
      res.byLang[lang] = { count: m, mean: mu, sd };
      g.forEach(p => { p.styleZ = {}; for (const k of STYLE_KEYS) p.styleZ[k] = (p.features[k] - mu[k]) / sd[k]; });
      const d = STYLE_KEYS.length;
      g.forEach((p, i) => {
        const z = STYLE_KEYS.map(k => clamp(p.styleZ[k], -4, 4));
        const global = Math.sqrt(z.reduce((s, x) => s + x * x, 0) / d) * (m > 1 ? m / (m - 1) : 1);
        let local = null;
        if (i >= 1) {
          const prev = g.slice(Math.max(0, i - 3), i);
          const pm = STYLE_KEYS.map(k => mean(prev.map(q => clamp(q.styleZ[k], -4, 4))));
          local = Math.sqrt(z.reduce((s, x, j) => s + (x - pm[j]) ** 2, 0) / d);
        }
        const top = STYLE_KEYS.map(k => [k, p.styleZ[k]]).filter(([, v]) => Math.abs(v) >= 1.5)
          .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1])).slice(0, 3)
          .map(([k, v]) => ({ key: k, label: STYLE_LABELS[k], z: round(v, 1), value: round(p.features[k], 2), docMean: round(mu[k], 2) }));
        p.style = {
          global: round(global, 2), local: round(local, 2), top,
          change: m >= 5 && local !== null && local >= 1.5 && global >= 1.2,
          comparedWith: m
        };
      });
    }
    res.series = paras.filter(p => p.style).map(p => ({ id: p.id, page: p.page, section: p.section, local: p.style.local, global: p.style.global, change: p.style.change }));
    // Bölümler arası üslup mesafesi (her dil içinde)
    for (const lang of Object.keys(groups)) {
      const bySec = {};
      for (const p of groups[lang]) (bySec[p.section] = bySec[p.section] || []).push(p);
      const secs = Object.keys(bySec);
      const vec = s => STYLE_KEYS.map(k => mean(bySec[s].map(p => clamp(p.styleZ[k], -4, 4))));
      for (let i = 0; i < secs.length; i++) for (let j = i + 1; j < secs.length; j++) {
        const a = vec(secs[i]), b = vec(secs[j]);
        const dist = Math.sqrt(a.reduce((s, x, k) => s + (x - b[k]) ** 2, 0) / STYLE_KEYS.length);
        res.sectionDistances.push({ lang, a: secs[i], b: secs[j], aLabel: SECTION_LABELS[secs[i]], bLabel: SECTION_LABELS[secs[j]], dist: round(dist, 2) });
      }
    }
    res.sectionDistances.sort((x, y) => y.dist - x.dist);
    return res;
  }

  // ---------------------------------------------------------------- Birleştirme
  function categorize(p, modelScore) {
    const h = p.layers.heuristic;
    const why = [];
    let cat;
    if (p.words < 40 || p.features.sentCount < 2) { cat = 5; why.push('Metin çok kısa (40 kelime altı veya tek cümle); güvenilir değerlendirme yapılamaz.'); }
    else if (modelScore !== null && Math.abs(h.score - modelScore) >= 45) { cat = 5; why.push(`Katmanlar çelişiyor (sezgisel ${h.score}, model ${modelScore}).`); }
    else if (p.combined < 35) cat = 1;
    else if (p.combined >= 65 && h.content >= 0.6) cat = 4;
    else if (p.layers.model && p.layers.model.probs && p.layers.model.probs.ai_edited !== undefined &&
      p.layers.model.probs.ai_edited >= Math.max(p.layers.model.probs.human || 0, p.layers.model.probs.ai_generated || 0)) { cat = 2; why.push('Eğitilmiş model en yüksek olasılığı “AI ile düzenlenmiş” sınıfına verdi.'); }
    else if (h.surface >= 0.5 && h.content < 0.5) { cat = 2; why.push('Yüzey cilası göstergeleri (kalıp ifade, bağlaç, düzenli cümle) yüksek; ancak içerik somut (atıf/sayı/özel ad).'); }
    else if (p.combined < 45 && h.surface < 0.5) { cat = 5; why.push('Göstergeler zayıf ve karışık.'); }
    else cat = 3;
    p.category = cat;
    p.categoryLabel = CATS[cat].label;
    p.color = CATS[cat].color;
    p.categoryWhy = why;
  }
  function confidenceOf(p, modelScore) {
    if (p.category === 5 || p.words < 80) return 'Düşük';
    if (modelScore === null) return p.words >= 120 ? 'Orta' : 'Düşük';
    return p.words >= 150 && Math.abs(p.layers.heuristic.score - modelScore) < 20 ? 'Yüksek' : 'Orta';
  }

  function finalize(res) {
    const ps = res.paragraphs;
    const hasModel = ps.some(p => p.layers.model);
    for (const p of ps) {
      const h = p.layers.heuristic.score;
      const m = p.layers.model ? Math.round(p.layers.model.ai_score * 100) : null;
      p.combined = m === null ? h : Math.round(COMBINE.withModel.heuristic * h + COMBINE.withModel.model * m);
      categorize(p, m);
      p.confidence = confidenceOf(p, m);
    }
    const scored = ps.filter(p => p.words >= 40);
    const tw = scored.reduce((s, p) => s + p.words, 0);
    const counts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    ps.forEach(p => counts[p.category]++);
    const bySec = {};
    for (const p of ps) {
      const s = (bySec[p.section] = bySec[p.section] || { key: p.section, label: SECTION_LABELS[p.section], paragraphs: 0, words: 0, wsum: 0, counts: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }, styleChanges: 0 });
      s.paragraphs++; s.counts[p.category]++;
      if (p.words >= 40) { s.words += p.words; s.wsum += p.combined * p.words; }
      if (p.style && p.style.change) s.styleChanges++;
    }
    const order = ['ozet', 'giris', 'literatur', 'yontem', 'bulgular', 'tartisma', 'sonuc', 'diger'];
    res.sections = order.filter(k => bySec[k]).map(k => { const s = bySec[k]; s.indicator = s.words ? Math.round(s.wsum / s.words) : null; delete s.wsum; return s; });
    res.summary = {
      overall: tw ? Math.round(scored.reduce((s, p) => s + p.combined * p.words, 0) / tw) : null,
      analyzed: ps.length,
      scored: scored.length,
      counts,
      green: counts[1], orange: counts[2] + counts[3], red: counts[4], yellow: counts[5],
      edited: counts[2], mixed: counts[3],
      styleChanges: ps.filter(p => p.style && p.style.change).length,
      hasModel,
      hasLLM: ps.some(p => p.layers.llm),
      combineRule: hasModel ? 'Birleşik gösterge = 0,5 × sezgisel puan + 0,5 × model puanı. LLM değerlendirmesi puana katılmaz.'
        : 'Birleşik gösterge = sezgisel puan (eğitilmiş model bağlı değil). LLM değerlendirmesi puana katılmaz.'
    };
    res.top10 = scored.slice().sort((a, b) => b.combined - a.combined).slice(0, 10).map(p => p.id);
    res.manualReview = scored.filter(p => p.category === 4 || p.combined >= 65 || (p.style && p.style.change && p.combined >= 50))
      .sort((a, b) => b.combined - a.combined).map(p => p.id);
    return res;
  }

  // ---------------------------------------------------------------- Ana akış
  function analyzeDocument(doc) {
    const all = doc.paragraphs.map(p => ({ ...p }));
    const fullText = all.map(p => p.text).join('\n');
    const docLang = detectLang(fullText);
    let section = 'diger', sectionTitle = '';
    for (const p of all) {
      if (p.kind === 'heading') {
        const s = sectionOf(p.text);
        if (s) section = s;
        sectionTitle = p.text;
        p.section = s || section; p.sectionTitle = p.text;
        continue;
      }
      const inl = inlineSection(p.text);
      if (inl && section !== 'kaynakca') { section = inl; sectionTitle = p.text.split(/[:.\-–—]/)[0]; }
      p.section = section; p.sectionTitle = sectionTitle || SECTION_LABELS[section];
    }
    const isRef = p => p.section === 'kaynakca' && (p.kind === 'para' || p.kind === 'list');
    const refs = all.filter(isRef);
    const analyzable = all.filter(p => p.kind !== 'heading' && !isRef(p));
    analyzable.forEach((p, i) => {
      p.index = i + 1;
      p.lang = p.text.split(/\s+/).length >= 20 ? detectLang(p.text) : docLang;
      p.features = paragraphFeatures(p.text, p.lang);
      p.words = p.features.words;
      const h = heuristicScore(p.features);
      p.layers = { heuristic: h, model: null, llm: null };
      p.reasons = reasonsOf(p.features, h);
    });
    const style = stylometry(analyzable);
    const res = {
      version: VERSION,
      fileName: doc.fileName,
      pageCount: doc.pageCount,
      pageApprox: !!doc.pageApprox,
      ocrPages: doc.ocrPages || [],
      lang: docLang,
      langs: uniq(analyzable.map(p => p.lang)),
      totalWords: countWords(fullText),
      totalParagraphs: all.filter(p => p.kind !== 'heading').length,
      headings: all.filter(p => p.kind === 'heading').length,
      all, paragraphs: analyzable, references: refs, style,
      weights: WEIGHTS
    };
    return finalize(res);
  }

  function applyModel(res, results) { // results: {id: {ai_score, probs, calibrated, model}}
    for (const p of res.paragraphs) if (results[p.id]) p.layers.model = results[p.id];
    return finalize(res);
  }
  function applyLLM(res, results) {
    for (const p of res.paragraphs) if (results[p.id]) p.layers.llm = results[p.id];
    res.summary.hasLLM = true;
    return res;
  }

  // ---------------------------------------------------------------- Uzman raporu (kural tabanlı)
  function expertReport(res, cites) {
    const S = res.summary, out = [];
    const ov = S.overall;
    const charac = ov === null ? 'değerlendirilemeyen' : ov < 35 ? 'ağırlıklı olarak insan yazımıyla uyumlu' : ov < 55 ? 'karma' : 'AI yazım karakteristikleriyle belirgin biçimde örtüşen';
    out.push({ q: 'Belge genel olarak nasıl bir yazım karakteristiğine sahip?',
      a: `Belge ${res.totalWords} kelime ve ${S.analyzed} analiz edilen paragraftan oluşuyor (dil: ${res.langs.map(l => l === 'tr' ? 'Türkçe' : 'İngilizce').join(', ')}). Birleşik gösterge %${ov ?? '–'}; belge genelinde ${charac} bir profil görülüyor. ${S.green} paragraf insan yazımıyla uyumlu, ${S.edited} paragrafta AI destekli dil düzenlemesi göstergesi, ${S.mixed} paragrafta karma gösterge, ${S.red} paragrafta güçlü AI üretimi göstergesi var; ${S.yellow} paragraf sonuçlandırılamadı.` });
    const secs = res.sections.filter(s => s.indicator !== null).sort((a, b) => b.indicator - a.indicator);
    out.push({ q: 'Hangi bölümler AI üretimiyle daha fazla benzerlik gösteriyor?',
      a: secs.length ? `En yüksek göstergeler: ${secs.slice(0, 3).map(s => `${s.label} (%${s.indicator})`).join(', ')}. En düşük: ${secs.slice(-1).map(s => `${s.label} (%${s.indicator})`).join('')}.` : 'Bölüm ayrımı yapılamadı (başlık bulunamadı).' });
    const ed = res.sections.filter(s => s.counts[2] > 0).sort((a, b) => b.counts[2] - a.counts[2]);
    out.push({ q: 'Hangi bölümlerde AI destekli dil düzenlemesine ilişkin göstergeler var?',
      a: ed.length ? ed.map(s => `${s.label}: ${s.counts[2]} paragraf`).join('; ') + '. Bu kategori, içeriği somut olup dili belirgin biçimde “cilalanmış” paragrafları kapsar.' : 'Bu kategoride paragraf bulunmadı.' });
    const ch = res.paragraphs.filter(p => p.style && p.style.change);
    const pages = uniq(ch.map(p => p.page)).sort((a, b) => a - b);
    out.push({ q: 'Üslup değişimleri hangi sayfalarda yoğunlaşıyor?',
      a: ch.length ? `${ch.length} paragrafta belirgin üslup değişimi saptandı; sayfalar: ${pages.join(', ')}${res.pageApprox ? ' (DOCX için sayfa numaraları tahminidir)' : ''}. Üslup değişimi tek başına AI kullanımını kanıtlamaz; farklı yazarlar, alıntılar veya bölüm türü farkları da neden olabilir.` : 'Belirgin ani üslup değişimi saptanmadı.' });
    const sd = res.style.sectionDistances.slice(0, 2);
    const consistent = !ch.length || ch.length / Math.max(1, S.scored) < 0.1;
    out.push({ q: 'Akademik anlatım tutarlı mı?',
      a: `${consistent ? 'Üslup büyük ölçüde tutarlı görünüyor.' : 'Belgede üslup tutarlılığı zayıf; birden fazla noktada kayma var.'}${sd.length ? ` Bölümler arası en büyük üslup farkı: ${sd.map(d => `${d.aLabel} ↔ ${d.bLabel} (${d.dist})`).join(', ')}.` : ''}` });
    if (cites) {
      const per1000 = res.totalWords ? (cites.inText.total / res.totalWords * 1000).toFixed(1) : '0';
      out.push({ q: 'Kaynak kullanımı yeterli mi?',
        a: `Metin içinde ${cites.inText.total} atıf (1000 kelimede ${per1000}) ve kaynakçada ${cites.references.length} kayıt bulundu. Kaynakçada karşılığı bulunamayan atıf: ${cites.unmatchedInText.length}; metinde atıf yapılmamış kaynak: ${cites.uncitedRefs.length}. Yeterlilik alan normlarına bağlıdır; bu sayılar manuel değerlendirme için başlangıç noktasıdır.` });
    }
    const mr = res.manualReview.map(id => res.paragraphs.find(p => p.id === id)).slice(0, 8);
    out.push({ q: 'Hangi bölümlerin manuel olarak incelenmesi önerilir?',
      a: mr.length ? mr.map(p => `Sayfa ${p.page}, ${SECTION_LABELS[p.section]}, paragraf ${p.index} (%${p.combined})`).join('; ') + '.' : 'Öncelikli manuel inceleme gerektiren paragraf saptanmadı.' });
    return out;
  }

  return {
    VERSION, CATS, SECTION_LABELS, WEIGHTS, COMBINE, STYLE_LABELS,
    analyzeDocument, applyModel, applyLLM, finalize, expertReport,
    paragraphFeatures, heuristicScore, splitSentences, detectLang, sectionOf, countWords, tokenize
  };
});
