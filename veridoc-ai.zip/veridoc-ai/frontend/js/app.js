/* VERIDOC AI — Arayüz denetleyicisi */
(function () {
  'use strict';
  const $ = s => document.querySelector(s);
  const A = window.AADAnalyzer, C = window.AADCitations, P = window.AADParser;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const COLOR = { green: '#15803d', yellow: '#b7860b', orange: '#e0620d', red: '#b91c1c' };
  const CAP = window.Capacitor;
  const isNative = !!(CAP && CAP.isNativePlatform && CAP.isNativePlatform());
  const plugin = n => (CAP && CAP.Plugins ? CAP.Plugins[n] : null);
  const SERVER_KEY = 'veridoc.server';
  const savedServer = () => { try { return localStorage.getItem(SERVER_KEY) || ''; } catch (e) { return ''; } };
  const state = { file: null, res: null, cites: null, backend: null, backendUrl: null, charts: [], filter: 'all' };

  // ---------------------------------------------------------------- Arka uç tespiti
  async function probe(url) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 1500);
    try { const r = await fetch(url + '/api/health', { signal: ctl.signal }); return r.ok ? await r.json() : null; }
    catch (e) { return null; } finally { clearTimeout(t); }
  }
  async function detectBackend() {
    state.backend = null; state.backendUrl = null;
    const cands = [];
    if (savedServer()) cands.push(savedServer().replace(/\/+$/, ''));
    if (!isNative) {
      if (location.protocol.startsWith('http')) cands.push(location.origin);
      cands.push('http://localhost:8000', 'http://127.0.0.1:8000');
    }
    for (const u of [...new Set(cands)]) { const h = await probe(u); if (h) { state.backend = h; state.backendUrl = u; break; } }
    renderLayerStatus();
  }
  function renderLayerStatus() {
    const b = state.backend;
    const cls = b && b.classifier && b.classifier.available;
    const llm = b && b.llm && b.llm.available;
    $('#layerStatus').innerHTML = `
      <span class="chip on" title="Tarayıcıda çalışır">Dilsel analiz</span>
      <span class="chip on" title="Tarayıcıda çalışır">Stilometri</span>
      <span class="chip ${cls ? 'on' : ''}" title="${cls ? esc(b.classifier.model) : 'Sunucuda eğitilmiş model yapılandırılmamış'}">Eğitilmiş model: ${cls ? 'bağlı' : 'yok'}</span>
      <span class="chip ${llm ? 'on' : ''}" title="${llm ? esc(b.llm.model) : 'Sunucuda API anahtarı yapılandırılmamış'}">LLM değerlendirmesi: ${llm ? 'hazır' : 'yok'}</span>`;
    $('#llmConsent').hidden = !llm;
    if (llm) $('#llmModelName').textContent = b.llm.model;
  }

  // ---------------------------------------------------------------- Yükleme
  const drop = $('#drop'), input = $('#fileInput');
  function setFile(f) {
    $('#uploadError').hidden = true;
    if (!f) return;
    if (!/\.(docx|pdf)$/i.test(f.name)) { showError(/\.doc$/i.test(f.name) ? 'Eski .doc biçimi desteklenmiyor. Word’de “Farklı Kaydet → .docx” kullanın.' : 'Yalnızca .docx veya .pdf dosyası yükleyebilirsiniz.'); return; }
    state.file = f;
    const kb = f.size / 1024;
    $('#fileInfo').textContent = `${f.name} — ${kb > 1024 ? (kb / 1024).toFixed(1) + ' MB' : Math.round(kb) + ' KB'}`;
    $('#fileInfo').hidden = false;
    $('#analyzeBtn').disabled = false;
  }
  function showError(m) { const e = $('#uploadError'); e.textContent = m; e.hidden = false; }
  input.addEventListener('change', () => setFile(input.files[0]));
  drop.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } });
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => setFile(e.dataTransfer.files[0]));
  $('#analyzeBtn').addEventListener('click', run);
  $('#btnNew').addEventListener('click', () => { show('upload'); input.value = ''; });
  $('#btnPdf').addEventListener('click', () => (isNative ? exportPdf() : window.print()));
  $('#btnServer').addEventListener('click', () => {
    const v = window.prompt('İsteğe bağlı analiz sunucusunun adresi (eğitilmiş model ve LLM katmanları için). Örnek: http://192.168.1.20:8000\nBoş bırakırsanız yalnızca cihaz içi analiz yapılır.', savedServer());
    if (v === null) return;
    try { if (v.trim()) localStorage.setItem(SERVER_KEY, v.trim()); else localStorage.removeItem(SERVER_KEY); } catch (e) { /* yoksay */ }
    detectBackend();
  });
  if (isNative && plugin('App')) {
    plugin('App').addListener('backButton', () => {
      if (!$('#modal').hidden) closeModal();
      else if (!$('#resultView').hidden) show('upload');
      else plugin('App').exitApp();
    });
  }
  $('#btnExcel').addEventListener('click', exportExcel);

  function show(v) { ['upload', 'progress', 'result'].forEach(x => { $('#' + x + 'View').hidden = x !== v; }); window.scrollTo(0, 0); }
  function progress(text, pct) { $('#progressText').textContent = text; if (pct !== undefined) $('#barFill').style.width = pct + '%'; }

  async function postJSON(path, body, timeout = 180000) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
    try {
      const r = await fetch(state.backendUrl + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: ctl.signal });
      if (!r.ok) throw new Error('Sunucu hatası ' + r.status + ': ' + (await r.text()).slice(0, 200));
      return await r.json();
    } finally { clearTimeout(t); }
  }

  // ---------------------------------------------------------------- Analiz akışı
  async function run() {
    if (!state.file) return;
    show('progress'); progress('Belge okunuyor…', 3);
    const notes = [];
    try {
      const doc = await P.parse(state.file, progress);
      const words = doc.paragraphs.reduce((s, p) => s + A.countWords(p.text), 0);
      if (words < 30) throw new Error('Belgeden yeterli metin çıkarılamadı. Taranmış bir PDF ise OCR için internet bağlantısı gerekir; parola korumalı belgeler okunamaz.');
      progress('Dilsel, istatistiksel ve stilometrik analiz yapılıyor…', 50);
      await new Promise(r => setTimeout(r, 30));
      const res = A.analyzeDocument(doc);
      const big = res.paragraphs.filter(p => p.words >= 40);

      if (state.backend && state.backend.classifier && state.backend.classifier.available && big.length) {
        progress('Eğitilmiş sınıflandırıcı çalıştırılıyor…', 62);
        try {
          const out = await postJSON('/api/classify', { paragraphs: big.map(p => ({ id: p.id, text: p.text, lang: p.lang })) });
          const map = {}; (out.results || []).forEach(r => { map[r.id] = r; });
          A.applyModel(res, map);
        } catch (e) { notes.push('Eğitilmiş model katmanı çalıştırılamadı: ' + e.message); }
      }
      if (state.backend && state.backend.llm && state.backend.llm.available && $('#llmCheck').checked && big.length) {
        progress('LLM destekli akademik değerlendirme yapılıyor (bu adım birkaç dakika sürebilir)…', 75);
        try {
          const sel = big.slice().sort((a, b) => b.combined - a.combined).slice(0, state.backend.llm.max_paragraphs || 30);
          const out = await postJSON('/api/llm-review', {
            consent: true, language: res.lang,
            paragraphs: sel.map(p => ({ id: p.id, text: p.text, section: A.SECTION_LABELS[p.section], page: p.page, heuristic: p.layers.heuristic.score })),
            context: { fileName: res.fileName, words: res.totalWords, sections: res.sections.map(s => ({ label: s.label, indicator: s.indicator })) }
          }, 600000);
          const map = {}; (out.results || []).forEach(r => { map[r.id] = r; });
          A.applyLLM(res, map);
          res.llmSummary = out.summary || null;
          res.llmModel = out.model;
        } catch (e) { notes.push('LLM katmanı çalıştırılamadı: ' + e.message); }
      }
      progress('Kaynakça ve atıflar inceleniyor…', 90);
      state.cites = C.analyze(res);
      res.notes = notes.concat(doc.warnings || []);
      state.res = res;
      progress('Rapor hazırlanıyor…', 98);
      render();
      show('result');
    } catch (e) {
      console.error(e);
      show('upload'); showError(e.message || String(e));
    }
  }

  // ---------------------------------------------------------------- Görselleştirme
  const byId = id => state.res.paragraphs.find(p => p.id === id);
  const pill = p => `<span class="score-pill c-${p.color}">%${p.combined}</span>`;
  const indicatorColor = v => v === null ? '#9aa3b5' : v < 35 ? COLOR.green : v < 50 ? COLOR.yellow : v < 65 ? COLOR.orange : COLOR.red;

  function render() {
    const r = state.res, S = r.summary;
    state.charts.forEach(c => c.destroy()); state.charts = [];
    $('#docTitle').textContent = r.fileName;
    $('#ringVal').textContent = S.overall === null ? '–' : '%' + S.overall;
    $('#ring').style.setProperty('--v', S.overall || 0);
    $('#ring').style.setProperty('--c', indicatorColor(S.overall));
    const fact = (k, v, c = '') => `<div class="${c}"><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`;
    $('#facts').innerHTML = [
      fact('Sayfa sayısı', r.pageCount + (r.pageApprox ? ' (tahmini)' : '')),
      fact('Kelime sayısı', r.totalWords.toLocaleString('tr-TR')),
      fact('Paragraf sayısı', r.totalParagraphs),
      fact('Analiz edilen paragraf', S.analyzed),
      fact('İnsan yazımıyla uyumlu', S.green, 'g'),
      fact('AI destekli düzenleme göstergesi', S.edited, 'o'),
      fact('Karma (insan + AI) göstergeler', S.mixed, 'o'),
      fact('Güçlü AI üretimi göstergesi', S.red, 'r'),
      fact('Belirsiz / sonuçlandırılamayan', S.yellow, 'y'),
      fact('Dil', r.langs.map(l => l === 'tr' ? 'Türkçe' : 'İngilizce').join(', ') || '–')
    ].join('') + (r.ocrPages.length ? fact('OCR uygulanan sayfalar', r.ocrPages.join(', ')) : '');

    // Belge haritası
    $('#strip').innerHTML = r.paragraphs.map(p => `<button class="c-${p.color}" data-id="${p.id}" title="Sayfa ${p.page} — ${esc(A.SECTION_LABELS[p.section])} — %${p.combined}" aria-label="Paragraf ${p.index}, gösterge %${p.combined}"></button>`).join('');
    $('#legend').innerHTML = `<span><i class="c-green"></i>İnsan yazımıyla uyumlu</span><span><i class="c-yellow"></i>Belirsiz</span><span><i class="c-orange"></i>AI destekli düzenleme / karma</span><span><i class="c-red"></i>AI üretimiyle uyumlu güçlü göstergeler</span>`;

    renderMethods();
    renderSections();
    $('#top10').innerHTML = r.top10.map(byId).map(p => `<li data-id="${p.id}">${pill(p)}<span class="meta">Sayfa ${p.page}${r.pageApprox ? '~' : ''} · ${esc(A.SECTION_LABELS[p.section])} · ${esc(p.categoryLabel)}</span>
      <div class="first">${esc(p.features.sentences[0] || p.text.slice(0, 160))}</div>
      <div class="meta">${esc(p.reasons.ai[0] || p.categoryWhy[0] || 'Belirgin tek bir gerekçe yok; birden fazla zayıf sinyal birleşiyor.')}</div></li>`).join('') || '<li>Yeterli uzunlukta paragraf yok.</li>';
    renderStyle();
    renderFilters(); renderParas();
    renderCites();
    const exp = A.expertReport(r, state.cites);
    $('#expert').innerHTML = (r.llmSummary ? `<div class="qa"><b>LLM destekli genel değerlendirme (${esc(r.llmModel || '')})</b><p>${esc(r.llmSummary)}</p><p class="muted small">Bu metin bir dil modelinin yorumudur; kesin tespit değildir.</p></div>` : '') +
      exp.map(x => `<div class="qa"><b>${esc(x.q)}</b><p>${esc(x.a)}</p></div>`).join('') +
      '<p class="muted small">Yukarıdaki yanıtlar ölçülen değerlerden kural tabanlı olarak üretilmiştir; bir uzmanın görüşünün yerini tutmaz.</p>';
    const mr = r.manualReview.map(byId);
    $('#manual').innerHTML = mr.length ? '<ol class="top10">' + mr.map(p => `<li data-id="${p.id}">${pill(p)} Sayfa ${p.page}, ${esc(A.SECTION_LABELS[p.section])}, paragraf ${p.index}${p.style && p.style.change ? ' — üslup değişimi' : ''}<div class="meta">${esc(p.features.sentences[0] || '')}</div></li>`).join('') + '</ol>'
      : '<p>Öncelikli manuel inceleme gerektiren paragraf saptanmadı. Yine de tüm sonuçların uzman gözüyle yorumlanması önerilir.</p>';
    renderLimits();
  }

  function renderMethods() {
    const r = state.res, S = r.summary, b = state.backend;
    const W = A.WEIGHTS;
    const m = (t, ok, st, body) => `<div class="method"><h4>${t}</h4><div class="st ${ok ? 't-green' : 't-yellow'}">${st}</div><p>${body}</p></div>`;
    let model = 'Sunucuda eğitilmiş bir sınıflandırıcı yapılandırılmadı. Bu katmanın yerine başka bir puan GÖSTERİLMEZ.';
    if (S.hasModel) {
      const c = b.classifier;
      model = `Model: ${esc(c.model)}. Kalibrasyon: ${c.calibrated ? 'sıcaklık ölçekleme uygulandı' : 'yok — puan olasılık olarak yorumlanmamalı'}.` +
        (c.metrics ? ` Test metrikleri: F1 ${c.metrics.f1_macro ?? '–'}, ROC-AUC ${c.metrics.roc_auc ?? '–'}, insan metinlerinde yanlış pozitif oranı ${c.metrics.human_fpr ?? '–'}.` : ' Bu model için değerlendirme metrikleri sunulmadı; performansı bilinmiyor.');
    }
    $('#methods').innerHTML =
      m('1. Dilsel ve istatistiksel analiz', true, 'Çalıştı', `Cümle uzunluğu ve değişkenliği, kelime çeşitliliği (TTR, MTLD), bağlaç yoğunluğu, kalıp ifadeler, cümle başlangıç çeşitliliği, somutluk. Ağırlıklar: düzenli cümle ${W.burst}, kalıp ifade ${W.phrase}, bağlaç ${W.conn}, tekdüze başlangıç ${W.start}, somutluk eksikliği ${W.spec}.`) +
      m('2. Stilometri ve yazarlık değişimi', true, 'Çalıştı', `Dokuz üslup özelliği belge içinde standartlaştırılıp her paragraf önceki üç paragrafla ve belge ortalamasıyla karşılaştırıldı. ${S.styleChanges} belirgin değişim. Diller ayrı değerlendirildi.`) +
      m('3. Eğitilmiş AI tespit modeli', S.hasModel, S.hasModel ? 'Çalıştı' : 'Bağlı değil', model) +
      m('4. LLM destekli akademik değerlendirme', S.hasLLM, S.hasLLM ? 'Çalıştı (onaylı)' : 'Kullanılmadı', S.hasLLM ? `Açıklayıcı yorum üretir; puana katılmaz. Model: ${esc(r.llmModel || '')}.` : 'İsteğe bağlıdır; sunucuda API anahtarı ve kullanıcı onayı gerekir.') +
      `<div class="method" style="grid-column:1/-1"><h4>Birleştirme kuralı</h4><p>${esc(S.combineRule)} Puanlar kalibre edilmemiş göstergelerdir; gerçek AI yazım olasılığı olarak sunulmaz.</p></div>`;
  }

  function chartOk() { return typeof window.Chart !== 'undefined'; }
  function renderSections() {
    const secs = state.res.sections;
    $('#secTable').innerHTML = `<div class="tbl-scroll"><table class="t"><thead><tr><th>Bölüm</th><th>Paragraf</th><th>Gösterge</th><th>İnsan</th><th>Düzenleme</th><th>Karma</th><th>Güçlü AI</th><th>Belirsiz</th><th>Üslup değişimi</th></tr></thead><tbody>` +
      secs.map(s => `<tr><td>${esc(s.label)}</td><td>${s.paragraphs}</td><td><b style="color:${indicatorColor(s.indicator)}">${s.indicator === null ? '–' : '%' + s.indicator}</b></td><td>${s.counts[1]}</td><td>${s.counts[2]}</td><td>${s.counts[3]}</td><td>${s.counts[4]}</td><td>${s.counts[5]}</td><td>${s.styleChanges}</td></tr>`).join('') + '</tbody></table></div>';
    if (!chartOk()) return;
    state.charts.push(new Chart($('#secChart'), {
      type: 'bar',
      data: { labels: secs.map(s => s.label), datasets: [{ label: 'AI yazım göstergesi (%)', data: secs.map(s => s.indicator), backgroundColor: secs.map(s => indicatorColor(s.indicator)), borderRadius: 4 }] },
      options: { maintainAspectRatio: false, scales: { y: { min: 0, max: 100 } }, plugins: { legend: { display: false } } }
    }));
  }

  function renderStyle() {
    const r = state.res;
    const ser = r.style.series.filter(s => s.local !== null);
    const dist = r.style.sectionDistances.slice(0, 6);
    $('#secDist').innerHTML = dist.length ? `<p class="small muted">Bölümler arası en büyük üslup farkları:</p><div class="tbl-scroll"><table class="t"><tbody>${dist.map(d => `<tr><td>${esc(d.aLabel)} ↔ ${esc(d.bLabel)}</td><td>${d.dist}</td><td class="muted">${d.lang === 'tr' ? 'Türkçe' : 'İngilizce'}</td></tr>`).join('')}</tbody></table></div>` : '';
    if (!chartOk() || !ser.length) return;
    state.charts.push(new Chart($('#styleChart'), {
      type: 'line',
      data: {
        labels: ser.map(s => 's.' + s.page),
        datasets: [{ label: 'Yerel üslup mesafesi', data: ser.map(s => s.local), borderColor: '#1e3a8a', tension: .25, pointRadius: ser.map(s => s.change ? 6 : 2),
          pointBackgroundColor: ser.map(s => s.change ? COLOR.red : '#1e3a8a') }]
      },
      options: { maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { title: (it) => { const s = ser[it[0].dataIndex]; return `Sayfa ${s.page} — ${A.SECTION_LABELS[s.section]}`; } } } },
        onClick: (e, els) => { if (els.length) openPara(ser[els[0].index].id); }, scales: { y: { beginAtZero: true } } }
    }));
  }

  function renderFilters() {
    const S = state.res.summary;
    const f = [['all', 'Tümü', S.analyzed], ['red', 'Güçlü AI', S.red], ['orange', 'Düzenleme / karma', S.orange], ['yellow', 'Belirsiz', S.yellow], ['green', 'İnsan', S.green], ['style', 'Üslup değişimi', S.styleChanges]];
    $('#filters').innerHTML = f.map(([k, l, n]) => `<button data-f="${k}" class="${state.filter === k ? 'on' : ''}">${l} (${n})</button>`).join('');
  }
  function renderParas() {
    const r = state.res, f = state.filter;
    const list = r.paragraphs.filter(p => f === 'all' || (f === 'style' ? p.style && p.style.change : p.color === f));
    $('#paraList').innerHTML = list.map(p => `<article class="pcard ${p.color}" data-id="${p.id}" tabindex="0">
      <div class="head"><b>%${p.combined}</b><span>Sayfa ${p.page}${r.pageApprox ? '~' : ''}</span><span>${esc(A.SECTION_LABELS[p.section])}</span><span>${esc(p.categoryLabel)}</span><span>Güven: ${p.confidence}</span>${p.style && p.style.change ? '<span class="t-red">Üslup değişimi</span>' : ''}<span>${p.words} kelime</span></div>
      <p class="txt">${esc(p.text.length > 260 ? p.text.slice(0, 260) + '…' : p.text)}</p>
      <p class="full">${esc(p.text)}<br><small>${esc([...p.reasons.ai, ...p.categoryWhy].join(' '))}</small></p></article>`).join('') || '<p class="muted">Bu filtrede paragraf yok.</p>';
  }

  document.addEventListener('click', e => {
    const fb = e.target.closest('#filters button');
    if (fb) { state.filter = fb.dataset.f; renderFilters(); renderParas(); return; }
    const t = e.target.closest('[data-id]');
    if (t && !e.target.closest('.modal')) openPara(t.dataset.id);
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeModal();
    if (e.key === 'Enter' && e.target.classList && e.target.classList.contains('pcard')) openPara(e.target.dataset.id);
  });
  $('#mClose').addEventListener('click', closeModal);
  $('#modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });
  function closeModal() { $('#modal').hidden = true; }

  function highlight(p) {
    const f = p.features, spans = [];
    if (f.aligned) {
      f.phraseHits.forEach(h => spans.push({ ...h, cls: 'phrase', tip: 'AI metinlerinde sık görülen kalıp' }));
      f.connHits.forEach(h => spans.push({ ...h, cls: 'conn', tip: 'Geçiş/bağlaç ifadesi' }));
      f.firstPerson.forEach(h => spans.push({ ...h, cls: 'fp', tip: 'İnsan yazımı lehine: deneyim/birinci şahıs' }));
    }
    const re = /\([^()]*?(?:19|20)\d{2}[a-z]?[^()]*?\)|\[\d+(?:\s*[-–,]\s*\d+)*\]/g; let m;
    while ((m = re.exec(p.text))) spans.push({ start: m.index, end: m.index + m[0].length, cls: 'cite', tip: 'Atıf' });
    spans.sort((a, b) => a.start - b.start || b.end - a.end);
    let out = '', pos = 0;
    for (const s of spans) { if (s.start < pos) continue; out += esc(p.text.slice(pos, s.start)) + `<mark class="${s.cls}" title="${s.tip}">${esc(p.text.slice(s.start, s.end))}</mark>`; pos = s.end; }
    return out + esc(p.text.slice(pos));
  }

  function openPara(id) {
    const r = state.res, p = byId(id); if (!p) return;
    const f = p.features, h = p.layers.heuristic, sm = r.style.byLang[p.lang];
    const row = (k, v, d) => `<tr><td>${k}</td><td>${v}</td><td class="muted">${d ?? ''}</td></tr>`;
    const fx = (x, n = 2) => x === null || x === undefined ? '–' : (+x).toFixed(n);
    const docMean = k => sm ? fx(sm.mean[k]) : '–';
    const SIG = { burst: 'Düzenli cümle uzunluğu', phrase: 'Kalıp ifade yoğunluğu', conn: 'Bağlaç yoğunluğu', start: 'Tekdüze cümle başlangıcı', spec: 'Somutluk eksikliği' };
    const model = p.layers.model, llm = p.layers.llm;
    $('#mBody').innerHTML = `
      <h2 id="mTitle">${pill(p)} Paragraf ${p.index}</h2>
      <p class="muted">Sayfa ${p.page}${r.pageApprox ? ' (tahmini)' : ''} · ${esc(p.sectionTitle || A.SECTION_LABELS[p.section])} · ${p.words} kelime · ${p.lang === 'tr' ? 'Türkçe' : 'İngilizce'}</p>
      <p><b class="t-${p.color}">${esc(p.categoryLabel)}</b> — güven düzeyi: <b>${p.confidence}</b>${p.categoryWhy.length ? '<br><span class="small">' + esc(p.categoryWhy.join(' ')) + '</span>' : ''}</p>
      <div class="full-text">${highlight(p)}</div>
      <p class="small muted"><mark class="phrase">kalıp ifade</mark> <mark class="conn">bağlaç</mark> <mark class="fp">deneyim ifadesi</mark> <mark class="cite">atıf</mark></p>
      <div class="mgrid">
        <div><h4>AI yazımı lehine göstergeler</h4><ul>${p.reasons.ai.map(x => `<li>${esc(x)}</li>`).join('') || '<li>Belirgin gösterge yok.</li>'}</ul></div>
        <div><h4>İnsan yazımı lehine göstergeler</h4><ul>${p.reasons.human.map(x => `<li>${esc(x)}</li>`).join('') || '<li>Belirgin gösterge yok.</li>'}</ul></div>
        <div><h4>Katman 1 — dilsel analiz (sezgisel puan %${h.score})</h4>
          <table class="kv">${Object.entries(h.signals).map(([k, v]) => row(SIG[k], fx(v), 'ağırlık ' + A.WEIGHTS[k])).join('')}${h.humanAdj ? row('İnsan göstergesi düzeltmesi', '−' + h.humanAdj, '') : ''}</table>
          <table class="kv" style="margin-top:8px"><tr><td class="muted">Özellik</td><td class="muted">Paragraf</td><td class="muted">Belge ort.</td></tr>
          ${row('Ortalama cümle uzunluğu', fx(f.meanSentLen, 1), docMean('meanSentLen'))}${row('Cümle uzunluğu değişkenliği', fx(f.sentLenCV), docMean('sentLenCV'))}
          ${row('Kelime çeşitliliği (TTR-50)', fx(f.ttr50), docMean('ttr50'))}${row('MTLD', fx(f.mtld, 0), '')}${row('Bağlaç / cümle', fx(f.connPerSent), docMean('connPerSent'))}
          ${row('Uzun kelime oranı', fx(f.longWordRatio), docMean('longWordRatio'))}${row('Somutluk / 100 kelime', fx(f.specificity, 1), docMean('specificity'))}${row('Cümle sayısı', f.sentCount, '')}</table>
          <ul class="small" style="margin-top:8px">${p.reasons.notes.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>
        <div><h4>Katman 2 — stilometri</h4>${p.style ? `<p class="small">Belgeye uzaklık: <b>${fx(p.style.global)}</b> · önceki paragraflara uzaklık: <b>${fx(p.style.local)}</b> · ${p.style.change ? '<b class="t-red">belirgin üslup değişimi</b>' : 'belirgin değişim yok'}</p>
          <ul>${p.style.top.map(t => `<li>${esc(t.label)}: ${t.value} (belge ort. ${t.docMean}; ${t.z > 0 ? '+' : ''}${t.z} sd)</li>`).join('') || '<li>Belge ortalamasından belirgin sapma yok.</li>'}</ul>
          <p class="small muted">Üslup farkı tek başına AI kullanımını kanıtlamaz.</p>` : '<p class="small">Paragraf kısa olduğu için (40 kelime altı) üslup karşılaştırması yapılmadı.</p>'}</div>
        <div><h4>Katman 3 — eğitilmiş model</h4>${model ? `<p class="small">Model puanı: <b>%${Math.round(model.ai_score * 100)}</b> ${model.calibrated ? '(kalibre)' : '(kalibre edilmemiş)'}</p>${model.probs ? `<table class="kv">${Object.entries(model.probs).map(([k, v]) => row({ human: 'İnsan', ai_edited: 'AI ile düzenlenmiş', ai_generated: 'AI üretimi' }[k] || k, fx(v), '')).join('')}</table>` : ''}` : '<p class="small">Eğitilmiş model bağlı değil; bu katman için puan yok.</p>'}</div>
        <div><h4>Katman 4 — LLM değerlendirmesi</h4>${llm ? `<p class="small">${esc(llm.assessment || '')}</p>${(llm.ai_features || []).length ? '<p class="small"><b>AI özellikleri:</b> ' + esc(llm.ai_features.join('; ')) + '</p>' : ''}${(llm.human_features || []).length ? '<p class="small"><b>İnsan özellikleri:</b> ' + esc(llm.human_features.join('; ')) + '</p>' : ''}${llm.category_suggestion ? '<p class="small"><b>Önerdiği kategori:</b> ' + esc(llm.category_suggestion) + '</p>' : ''}<p class="small muted">Dil modeli yorumudur; puana katılmaz.</p>` : '<p class="small">Bu paragraf için LLM değerlendirmesi yapılmadı.</p>'}</div>
      </div>`;
    $('#modal').hidden = false;
    $('#mClose').focus();
  }

  // ---------------------------------------------------------------- Kaynakça
  const VS = { verified: 'Doğrulandı', probable: 'Olası eşleşme', mismatch: 'Bilgi uyuşmazlığı', notfound: 'Bulunamadı', unverified: 'Doğrulanamadı', error: 'Sorgu hatası', skipped: 'Atlandı' };
  function renderCites() {
    const c = state.cites;
    if (!c.references.length && !c.inText.total) { $('#cites').innerHTML = '<p>Belgede kaynakça başlığı veya metin içi atıf bulunamadı. Kaynakça “Kaynakça / Kaynaklar / References” başlığı altında değilse otomatik ayrıştırılamaz.</p>'; return; }
    const verified = c.references.filter(r => r.verify);
    $('#cites').innerHTML = `<div class="cite-grid">
        <div><b>${c.inText.total}</b>metin içi atıf</div><div><b>${c.references.length}</b>kaynakça kaydı</div><div><b>${c.dois}</b>DOI içeren kayıt</div>
        <div><b>${c.unmatchedInText.length + c.unmatchedNumeric.length}</b>kaynakçada karşılığı olmayan atıf</div><div><b>${c.uncitedRefs.length}</b>metinde atıf yapılmamış kaynak</div><div><b>${c.noYear.length}</b>yılı bulunamayan kayıt</div></div>
      <p class="small muted">${esc(c.note)}</p>
      <div class="no-print"><button class="btn" id="btnVerify" ${c.references.length ? '' : 'disabled'}>Kaynakları çevrimiçi doğrula (Crossref / DataCite)</button>
      <p class="small muted">Yalnızca DOI’ler ve kaynakça satırları gönderilir; belge metni gönderilmez. İnternet bağlantısı gerekir.</p><p id="verifyProg" class="small"></p></div>
      ${c.unmatchedInText.length ? `<details><summary>Kaynakçada karşılığı bulunamayan atıflar (${c.unmatchedInText.length})</summary><ul>${c.unmatchedInText.map(u => `<li>${esc(u.raw)} — sayfa ${u.page}</li>`).join('')}</ul></details>` : ''}
      ${c.unmatchedNumeric.length ? `<details><summary>Karşılığı olmayan numaralı atıflar (${c.unmatchedNumeric.length})</summary><p>${c.unmatchedNumeric.map(n => '[' + n + ']').join(', ')}</p></details>` : ''}
      ${c.uncitedRefs.length ? `<details><summary>Metinde atıf yapılmamış kaynaklar (${c.uncitedRefs.length})</summary><ul>${c.uncitedRefs.map(r => `<li>${esc(r.text)}</li>`).join('')}</ul></details>` : ''}
      ${c.duplicates.length ? `<details><summary>Aynı yazar-yıl ile birden fazla kayıt (${c.duplicates.length})</summary><ul>${c.duplicates.map(r => `<li>${esc(r.text)}</li>`).join('')}</ul></details>` : ''}
      <details ${verified.length ? 'open' : ''}><summary>Tüm kaynakça kayıtları (${c.references.length})</summary><div class="tbl-scroll"><table class="t"><thead><tr><th>#</th><th>Kaynak</th><th>DOI</th><th>Doğrulama</th></tr></thead><tbody>
      ${c.references.map((r, i) => `<tr><td>${i + 1}</td><td>${esc(r.text)}</td><td>${r.doi ? esc(r.doi) : '<span class="muted">–</span>'}</td><td>${r.verify ? `<span class="vs ${r.verify.status}">${VS[r.verify.status]}</span><br><span class="small">${esc(r.verify.detail)}${r.verify.title ? '<br><i>' + esc(r.verify.title) + '</i>' : ''}</span>` : '<span class="muted small">Doğrulanmadı</span>'}</td></tr>`).join('')}
      </tbody></table></div></details>`;
    const vb = $('#btnVerify');
    if (vb) vb.addEventListener('click', async () => {
      vb.disabled = true;
      await C.verify(c.references, (i, n) => { $('#verifyProg').textContent = `Kontrol ediliyor: ${i}/${n}`; });
      renderCites();
    });
  }

  function renderLimits() {
    const r = state.res;
    const items = [
      'Bu uygulama kesin AI tespiti yapmaz. Sonuçlar karar destek amaçlıdır ve tek başına disiplin veya etik kararına dayanak olmamalıdır.',
      'Akademik metinlerdeki standart kalıplar, düzgün dil bilgisi ve uzun, düzenli cümleler AI kanıtı değildir.',
      'İnsan tarafından yazılmış metinler yanlışlıkla AI olarak işaretlenebilir; özellikle ana dili farklı yazarlar ve kalıplaşmış alan yazımı risklidir.',
      'AI ile dil bilgisi/üslup düzeltmesi yapılmış metinler tamamen AI üretimi olarak değerlendirilmez; ayrı kategoride gösterilir. Bu ayrım sezgisel göstergelere dayanır ve sınırlıdır.',
      'Kısa paragraflarda (80 kelime altı) güven düzeyi düşürülür; 40 kelime altı paragraflar sonuçlandırılmaz.',
      'Katman 1 ve 2 puanları sezgiseldir ve kalibre edilmemiştir. Eşikler ve ağırlıklar etiketli bir veri kümesinde doğrulanmamıştır.',
      r.summary.hasModel ? 'Eğitilmiş modelin Türkçe ve İngilizce performansı ayrı ayrı raporlanmalıdır; metrikler “Analiz yöntemleri” bölümündedir.' : 'Bu analizde eğitilmiş sınıflandırıcı kullanılmadı. Türkçe ve İngilizce için ayrı performans değerlendirmesi ancak model eğitilip test edildiğinde yapılabilir.',
      'Kalıp ifade sözlüğü yaygın İngilizce ve Türkçe AI ifadelerini içerir; güncel modeller bu kalıpları kullanmayabilir.',
      r.pageApprox ? 'Word belgelerinde sayfa numaraları kelime sayısından tahmin edilmiştir (yaklaşık 330 kelime/sayfa).' : 'PDF’de çok sütunlu düzenlerde paragraf sırası bozulabilir.',
      'Kaynak doğrulaması yalnızca Crossref ve DataCite kayıtlarını kapsar; kitaplar, tezler ve bazı ulusal dergiler bu kayıtlarda bulunmayabilir.'
    ];
    $('#limits').innerHTML = '<ul>' + items.map(x => `<li>${esc(x)}</li>`).join('') + '</ul>' + (r.notes && r.notes.length ? '<p><b>Bu analize özel notlar:</b></p><ul>' + r.notes.map(x => `<li>${esc(x)}</li>`).join('') + '</ul>' : '');
  }

  // ---------------------------------------------------------------- Excel
  function exportExcel() {
    if (!window.XLSX) { alert('Excel kütüphanesi yüklenemedi. İnternet bağlantınızı kontrol edin.'); return; }
    const r = state.res, S = r.summary, c = state.cites;
    const wb = XLSX.utils.book_new();
    const summary = [
      ['VeriDoc AI raporu', ''], ['Dosya', r.fileName], ['Tarih', new Date().toLocaleString('tr-TR')],
      ['Sayfa sayısı', r.pageCount + (r.pageApprox ? ' (tahmini)' : '')], ['Kelime sayısı', r.totalWords], ['Paragraf sayısı', r.totalParagraphs],
      ['Analiz edilen paragraf', S.analyzed], ['AI yazım göstergesi (%)', S.overall], ['İnsan yazımıyla uyumlu', S.green],
      ['AI destekli düzenleme göstergesi', S.edited], ['Karma göstergeler', S.mixed], ['Güçlü AI göstergesi', S.red], ['Belirsiz', S.yellow],
      ['Üslup değişimi', S.styleChanges], ['Birleştirme kuralı', S.combineRule],
      ['Uyarı', 'Gösterge, metnin AI yazım karakteristikleriyle örtüşme düzeyidir; gerçek AI kullanım oranı veya kesin yazarlık olasılığı değildir.']
    ];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(summary), 'Özet');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(r.paragraphs.map(p => ({
      'Sıra': p.index, 'Sayfa': p.page, 'Bölüm': A.SECTION_LABELS[p.section], 'Başlık': p.sectionTitle || '', 'Kategori': p.categoryLabel,
      'AI göstergesi (%)': p.combined, 'Sezgisel puan': p.layers.heuristic.score, 'Model puanı': p.layers.model ? Math.round(p.layers.model.ai_score * 100) : '',
      'Üslup değişimi': p.style && p.style.change ? 'Var' : 'Yok', 'Güven': p.confidence, 'Kelime': p.words, 'Dil': p.lang,
      'AI lehine göstergeler': p.reasons.ai.join(' | '), 'İnsan lehine göstergeler': p.reasons.human.join(' | '),
      'LLM yorumu': p.layers.llm ? p.layers.llm.assessment || '' : '', 'Metin': p.text
    }))), 'Paragraflar');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(r.sections.map(s => ({
      'Bölüm': s.label, 'Paragraf': s.paragraphs, 'Gösterge (%)': s.indicator, 'İnsan': s.counts[1], 'Düzenleme': s.counts[2], 'Karma': s.counts[3], 'Güçlü AI': s.counts[4], 'Belirsiz': s.counts[5], 'Üslup değişimi': s.styleChanges
    }))), 'Bölümler');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(c.references.map((x, i) => ({
      '#': i + 1, 'Kaynak': x.text, 'DOI': x.doi || '', 'Yıl': x.year || '', 'Metinde atıf': x.cited ? 'Evet' : 'Hayır',
      'Doğrulama': x.verify ? VS[x.verify.status] : 'Yapılmadı', 'Ayrıntı': x.verify ? x.verify.detail : ''
    }))), 'Kaynakça');
    const name = safeName(r.fileName) + '_AI_analiz.xlsx';
    saveFile(name, XLSX.write(wb, { bookType: 'xlsx', type: 'base64' }), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  }

  const safeName = n => n.replace(/\.(docx|pdf)$/i, '').replace(/[^\p{L}\p{N}_-]+/gu, '_').slice(0, 60);

  // Web: indirme bağlantısı. Android: önbelleğe yaz + paylaş menüsü (Drive, Dosyalar, e-posta…)
  async function saveFile(name, base64, mime) {
    if (isNative && plugin('Filesystem') && plugin('Share')) {
      try {
        const w = await plugin('Filesystem').writeFile({ path: name, data: base64, directory: 'CACHE' });
        await plugin('Share').share({ title: name, url: w.uri, dialogTitle: 'Raporu kaydet veya paylaş' });
      } catch (e) { if (!/cancel/i.test(String(e && e.message))) alert('Dosya kaydedilemedi: ' + (e.message || e)); }
      return;
    }
    const bin = atob(base64), u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([u8], { type: mime }));
    const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  // Android'de yazdırma olmadığı için rapor sayfası görüntü olarak PDF'e aktarılır
  async function exportPdf() {
    if (!window.html2canvas || !window.jspdf) { alert('PDF modülü yüklenemedi.'); return; }
    const btn = $('#btnPdf'), label = btn.textContent;
    btn.disabled = true; btn.textContent = 'PDF hazırlanıyor…';
    document.body.classList.add('pdf-mode');
    try {
      const pdf = new window.jspdf.jsPDF({ unit: 'pt', format: 'a4' });
      const pw = pdf.internal.pageSize.getWidth(), ph = pdf.internal.pageSize.getHeight(), m = 28;
      const parts = [];
      document.querySelectorAll('#resultView > .hero, #resultView > .strip-wrap, #resultView > .block').forEach(el => {
        if (el.querySelector('#paraList')) {
          parts.push(el.querySelector('h3'));
          el.querySelectorAll('.pcard').forEach(c => parts.push(c));
        } else parts.push(el);
      });
      let y = m;
      for (let i = 0; i < parts.length; i++) {
        btn.textContent = `PDF hazırlanıyor… ${Math.round((i / parts.length) * 100)}%`;
        const cv = await window.html2canvas(parts[i], { scale: 1.6, backgroundColor: '#ffffff', logging: false });
        const w = pw - 2 * m, k = w / cv.width;
        let sy = 0;
        while (sy < cv.height) {
          let avail = (ph - m - y) / k;
          if (avail < Math.min(80, cv.height - sy)) { pdf.addPage(); y = m; avail = (ph - 2 * m) / k; }
          const sh = Math.min(avail, cv.height - sy);
          const piece = document.createElement('canvas'); piece.width = cv.width; piece.height = Math.ceil(sh);
          piece.getContext('2d').drawImage(cv, 0, sy, cv.width, sh, 0, 0, cv.width, sh);
          pdf.addImage(piece.toDataURL('image/jpeg', 0.86), 'JPEG', m, y, w, sh * k);
          y += sh * k + 8; sy += sh;
        }
      }
      const total = pdf.internal.getNumberOfPages();
      for (let i = 1; i <= total; i++) { pdf.setPage(i); pdf.setFontSize(8); pdf.setTextColor(120); pdf.text(`VeriDoc AI  |  ${i} / ${total}`, pw - m, ph - 12, { align: 'right' }); }
      await saveFile(safeName(state.res.fileName) + '_AI_rapor.pdf', pdf.output('datauristring').split(',')[1], 'application/pdf');
    } catch (e) { console.error(e); alert('PDF oluşturulamadı: ' + (e.message || e)); }
    finally { document.body.classList.remove('pdf-mode'); btn.disabled = false; btn.textContent = label; }
  }

  if (isNative) $('#btnPdf').textContent = 'PDF rapor indir';
  detectBackend();
})();
