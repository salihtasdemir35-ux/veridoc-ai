/*
 * VERIDOC AI — Belge okuyucu
 * DOCX: mammoth.js   PDF: pdf.js   Taranmış PDF: tesseract.js (OCR)
 * Tümü tarayıcıda, yerel olarak çalışır.
 */
(function (root) {
  'use strict';
  const PDF_WORKER = 'vendor/pdf.worker.min.js';
  const TESSERACT_URL = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
  function loadScript(src) {
    return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('yüklenemedi')); document.head.appendChild(s); });
  }
  const WORDS_PER_PAGE = 330; // DOCX sayfa tahmini
  const CAPTION_RE = /^(Tablo|Şekil|Grafik|Resim|Table|Figure|Fig\.)\s*\d+/i;
  const clean = s => (s || '').replace(/\u00ad/g, '').replace(/[\u200b\ufeff]/g, '').replace(/\s+/g, ' ').trim();
  const countWords = t => (t.match(/[\p{L}\p{N}]+/gu) || []).length;
  const median = a => { if (!a.length) return 0; const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
  const A = () => root.AADAnalyzer;

  async function parse(file, onProgress) {
    const name = file.name.toLowerCase();
    if (name.endsWith('.docx')) return parseDocx(file, onProgress);
    if (name.endsWith('.pdf')) return parsePdf(file, onProgress);
    if (name.endsWith('.doc')) throw new Error('Eski .doc biçimi desteklenmiyor. Belgeyi Word’de açıp “Farklı Kaydet → .docx” ile kaydedin.');
    throw new Error('Yalnızca .docx ve .pdf dosyaları desteklenir.');
  }

  // ------------------------------------------------------------------ DOCX
  async function parseDocx(file, onProgress) {
    if (!root.mammoth) throw new Error('DOCX okuyucu (mammoth.js) yüklenemedi. İnternet bağlantınızı kontrol edip sayfayı yenileyin.');
    onProgress && onProgress('Word belgesi okunuyor…', 10);
    const res = await root.mammoth.convertToHtml({ arrayBuffer: await file.arrayBuffer() }, {
      styleMap: ["p[style-name='Title'] => h1:fresh", "p[style-name='Başlık'] => h1:fresh", "p[style-name='Puesto'] => h1:fresh",
        "p[style-name='Caption'] => p.caption:fresh", "p[style-name='Resim Yazısı'] => p.caption:fresh", "p[style-name='Açıklama'] => p.caption:fresh"]
    });
    const dom = new DOMParser().parseFromString(res.value, 'text/html');
    const out = []; let words = 0, id = 0;
    const push = (text, kind) => {
      text = clean(text); if (!text) return;
      out.push({ id: 'p' + (++id), text, kind, page: Math.floor(words / WORDS_PER_PAGE) + 1, pageApprox: true });
      words += countWords(text);
    };
    const walk = parent => {
      for (const el of parent.children) {
        const tag = el.tagName.toLowerCase();
        const text = clean(el.textContent);
        if (/^h[1-6]$/.test(tag)) push(text, 'heading');
        else if (tag === 'p') {
          if (!text) continue;
          const strong = clean([...el.querySelectorAll('strong,b')].map(x => x.textContent).join(''));
          const wc = countWords(text);
          if (el.classList.contains('caption') || CAPTION_RE.test(text)) push(text, 'caption');
          else if ((strong === text && wc <= 12 && !/[.;,]$/.test(text)) || (wc <= 6 && A().sectionOf(text))) push(text, 'heading');
          else push(text, 'para');
        } else if (tag === 'ul' || tag === 'ol') {
          const items = [...el.querySelectorAll(':scope > li')].map(li => clean(li.textContent)).filter(Boolean);
          if (items.length) push(items.join(' '), 'list');
        } else if (tag === 'table') {
          const rows = [...el.querySelectorAll('tr')].map(tr => [...tr.querySelectorAll('td,th')].map(td => clean(td.textContent)).filter(Boolean).join(' | ')).filter(Boolean);
          if (rows.length) push('Tablo içeriği: ' + rows.join(' / '), 'table');
        } else walk(el);
      }
    };
    walk(dom.body);
    onProgress && onProgress('Metin çıkarıldı', 40);
    return { fileName: file.name, paragraphs: out, pageCount: Math.max(1, Math.ceil(words / WORDS_PER_PAGE)), pageApprox: true, ocrPages: [],
      warnings: (res.messages || []).filter(m => m.type === 'error').map(m => m.message) };
  }

  // ------------------------------------------------------------------- PDF
  function buildLines(items) {
    const its = items.filter(i => typeof i.str === 'string' && i.str.trim() !== '')
      .map(i => ({ str: i.str, x: i.transform[4], y: i.transform[5], h: Math.abs(i.height || i.transform[3]) || 10, w: i.width || 0 }))
      .sort((a, b) => (b.y - a.y) || (a.x - b.x));
    const lines = [];
    for (const it of its) {
      const cur = lines[lines.length - 1];
      if (cur && Math.abs(cur.y - it.y) <= Math.max(2, it.h * 0.45)) cur.items.push(it);
      else lines.push({ y: it.y, items: [it] });
    }
    return lines.map(l => {
      l.items.sort((a, b) => a.x - b.x);
      let text = '';
      l.items.forEach((it, k) => {
        if (k > 0) {
          const prev = l.items[k - 1];
          const gap = it.x - (prev.x + prev.w);
          if (gap > prev.h * 0.15 && !text.endsWith(' ') && !it.str.startsWith(' ')) text += ' ';
        }
        text += it.str;
      });
      return { text: clean(text), y: l.y, x: Math.min(...l.items.map(i => i.x)), h: Math.max(...l.items.map(i => i.h)) };
    }).filter(l => l.text);
  }

  async function ocrPage(page, onProgress, pnum) {
    if (!root.Tesseract) {
      if (parsePdf._ocrUnavailable) return null;
      try { onProgress && onProgress('OCR modülü indiriliyor (internet gerekir)…'); await loadScript(TESSERACT_URL); }
      catch (e) { parsePdf._ocrUnavailable = true; return null; }
    }
    try {
      if (!parsePdf._worker) {
        onProgress && onProgress('OCR motoru hazırlanıyor (ilk seferde dil verisi indirilir)…');
        parsePdf._worker = await root.Tesseract.createWorker('tur+eng');
      }
      const vp = page.getViewport({ scale: 2 });
      const canvas = document.createElement('canvas');
      canvas.width = vp.width; canvas.height = vp.height;
      await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
      onProgress && onProgress(`Sayfa ${pnum}: taranmış görüntü, OCR uygulanıyor…`);
      const { data } = await parsePdf._worker.recognize(canvas);
      const lines = []; let y = 100000;
      for (const raw of (data.text || '').split('\n')) {
        if (!raw.trim()) { y -= 30; continue; }
        lines.push({ text: clean(raw), y, x: 0, h: 10, ocr: true }); y -= 12;
      }
      return lines.length ? lines : null;
    } catch (e) { console.warn('OCR hatası', e); return null; }
  }

  function looksLikeHeading(line, bodyH) {
    const t = line.text; const wc = countWords(t);
    if (wc === 0 || wc > 12 || t.length > 120 || /[.,;]$/.test(t)) return false;
    if (CAPTION_RE.test(t)) return false;
    if (A().sectionOf(t)) return true;
    if (!line.ocr && line.h >= bodyH * 1.15) return true;
    if (t === t.toLocaleUpperCase('tr-TR') && /\p{L}{3}/u.test(t) && wc <= 10) return true;
    if (/^\d+(\.\d+)*\.?\s+\p{Lu}/u.test(t) && wc <= 10) return true;
    return false;
  }

  async function parsePdf(file, onProgress) {
    const lib = root.pdfjsLib;
    if (!lib) throw new Error('PDF okuyucu (pdf.js) yüklenemedi. İnternet bağlantınızı kontrol edip sayfayı yenileyin.');
    lib.GlobalWorkerOptions.workerSrc = PDF_WORKER;
    const pdf = await lib.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
    const pages = [], ocrPages = [], ocrMissed = [];
    parsePdf._ocrUnavailable = false;
    for (let p = 1; p <= pdf.numPages; p++) {
      onProgress && onProgress(`PDF sayfası okunuyor: ${p}/${pdf.numPages}`, 5 + Math.round((p / pdf.numPages) * 35));
      const page = await pdf.getPage(p);
      let lines = buildLines((await page.getTextContent()).items);
      if (lines.reduce((s, l) => s + l.text.length, 0) < 40) {
        const o = await ocrPage(page, onProgress, p);
        if (o) { lines = o; ocrPages.push(p); } else ocrMissed.push(p);
      }
      pages.push({ num: p, lines });
    }
    if (parsePdf._worker) { try { await parsePdf._worker.terminate(); } catch (e) { /* yoksay */ } parsePdf._worker = null; }

    // Üst/alt bilgi satırlarını ayıkla (sayfaların yarısında tekrar edenler)
    if (pages.length >= 3) {
      const norm = t => t.replace(/\d+/g, '#').toLowerCase();
      const cnt = new Map();
      pages.forEach(pg => { const cand = [...pg.lines.slice(0, 2), ...pg.lines.slice(-2)]; new Set(cand.map(l => norm(l.text))).forEach(k => cnt.set(k, (cnt.get(k) || 0) + 1)); });
      const thr = Math.max(3, pages.length * 0.5);
      pages.forEach(pg => {
        const n = pg.lines.length;
        pg.lines = pg.lines.filter((l, i) => !((i < 2 || i >= n - 2) && (cnt.get(norm(l.text)) || 0) >= thr));
      });
    }

    const bodyH = median(pages.flatMap(pg => pg.lines.filter(l => !l.ocr).map(l => l.h))) || 10;
    const gaps = [];
    pages.forEach(pg => pg.lines.forEach((l, i) => { if (i) { const g = pg.lines[i - 1].y - l.y; if (g > 0 && g < bodyH * 6) gaps.push(g); } }));
    const medGap = median(gaps) || bodyH * 1.2;
    const bodyX = median(pages.flatMap(pg => pg.lines.map(l => l.x)));

    const out = []; let id = 0, cur = null;
    const flush = () => { if (cur && cur.text) out.push(cur); cur = null; };
    const start = (text, page, kind) => { flush(); cur = { id: 'p' + (++id), text, page, kind, lines: [text] }; };
    for (const pg of pages) {
      let prev = null;
      for (const line of pg.lines) {
        const t = line.text;
        if (/^[-–]?\s*\d{1,4}\s*[-–]?$/.test(t)) continue; // sayfa numarası
        if (looksLikeHeading(line, bodyH)) { flush(); out.push({ id: 'p' + (++id), text: t, page: pg.num, kind: 'heading' }); prev = line; continue; }
        if (CAPTION_RE.test(t)) { start(t, pg.num, 'caption'); prev = line; continue; }
        let newPara;
        if (!cur) newPara = true;
        else if (!prev) newPara = /[.!?:]["”)]?$/.test(cur.text) || !/^[\p{Ll}(]/u.test(t); // sayfa geçişi
        else {
          const gap = prev.y - line.y;
          const indent = line.x - bodyX > bodyH * 1.2 && /[.!?:]["”)]?$/.test(cur.text);
          newPara = gap > medGap * 1.35 || gap < 0 || indent;
        }
        if (newPara) start(t, pg.num, 'para');
        else {
          if (/[\p{L}]-$/u.test(cur.text) && /^\p{Ll}/u.test(t)) cur.text = cur.text.slice(0, -1) + t;
          else cur.text += ' ' + t;
          cur.lines.push(t);
          if (cur.kind === 'caption' && cur.lines.length > 3) cur.kind = 'para';
        }
        prev = line;
      }
    }
    flush();
    onProgress && onProgress('Metin çıkarıldı', 40);
    return { fileName: file.name, paragraphs: out, pageCount: pdf.numPages, pageApprox: false, ocrPages,
      warnings: ocrMissed.length ? [`${ocrMissed.length} sayfa taranmış görüntü gibi görünüyor ancak OCR yapılamadı (sayfalar: ${ocrMissed.slice(0, 20).join(', ')}). OCR ilk kullanımda internet bağlantısı gerektirir.`] : [] };
  }

  root.AADParser = { parse, parseDocx, parsePdf };
})(typeof self !== 'undefined' ? self : this);
