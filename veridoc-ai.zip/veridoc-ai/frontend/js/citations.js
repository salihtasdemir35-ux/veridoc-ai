/*
 * VERIDOC AI — Kaynakça ve atıf kontrolü
 * AI tespitinden BAĞIMSIZ bir değerlendirmedir.
 * Hiçbir kaynak bilgisi üretilmez; yalnızca belgede bulunanlar eşleştirilir ve
 * kullanıcı isterse Crossref / DataCite üzerinden doğrulanır.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.AADCitations = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const fold = s => s.toLocaleLowerCase('tr-TR')
    .replace(/[çÇ]/g, 'c').replace(/[ğĞ]/g, 'g').replace(/[ıİ]/g, 'i').replace(/[öÖ]/g, 'o')
    .replace(/[şŞ]/g, 's').replace(/[üÜ]/g, 'u').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const DOI_RE = /10\.\d{4,9}\/[^\s"<>]+/gi;
  const cleanDoi = d => d.replace(/[.,;)\]]+$/, '');
  const YEAR_RE = /(?<!\d)((?:19|20)\d{2})[a-zğ]?(?!\d)/;
  const ENTRY_START = /^(\[\d+\]|\d{1,3}[.)]\s|\p{Lu}[\p{L}'’\-]+(?:\s\p{Lu}[\p{L}'’\-]+)?,\s*(?:\p{Lu}\.|\p{Lu}[\p{Ll}]+)|\p{Lu}[\p{L}\-]+\s\(\d{4})/u;
  const NOT_SURNAME = new Set(['bkz', 'see', 'örn', 'e.g', 'tablo', 'şekil', 'table', 'figure', 'ek', 'appendix', 'aktaran', 'cited', 'in', 'akt', 'vd', 'and', 've', 'et', 'al', 'ark']);

  function splitEntries(refParas) {
    const entries = [];
    for (const p of refParas) {
      const lines = (p.lines && p.lines.length > 1) ? p.lines : [p.text];
      let cur = null;
      for (const raw of lines) {
        const l = raw.trim(); if (!l) continue;
        if (!cur || ENTRY_START.test(l)) { if (cur) entries.push(cur); cur = { text: l, page: p.page }; }
        else cur.text += (cur.text.endsWith('-') ? '' : ' ') + l;
      }
      if (cur) entries.push(cur);
    }
    return entries.filter(e => e.text.length > 15).map((e, i) => {
      const num = e.text.match(/^\[(\d+)\]|^(\d{1,3})[.)]\s/);
      const sm = e.text.replace(/^\[\d+\]\s*|^\d{1,3}[.)]\s*/, '').match(/^([\p{L}'’\-]+)/u);
      const year = (e.text.match(YEAR_RE) || [])[1] || null;
      const doiM = e.text.match(DOI_RE);
      const title = guessTitle(e.text);
      return { id: 'r' + (i + 1), text: e.text, page: e.page, number: num ? +(num[1] || num[2]) : null,
        surname: sm ? sm[1] : null, key: sm && year ? fold(sm[1]) + '|' + year : null,
        year, doi: doiM ? cleanDoi(doiM[0]) : null, title, cited: false, verify: null };
    });
  }
  function guessTitle(t) {
    const m = t.match(/\(\d{4}[a-z]?\)\.?\s*(.+?)[.?!](?:\s|$)/);
    if (m) return m[1].trim();
    const q = t.match(/[“"](.+?)[”"]/); return q ? q[1] : null;
  }

  function extractInText(paragraphs) {
    const items = [];
    const numeric = [];
    for (const p of paragraphs) {
      const t = p.text;
      let m; const par = /\(([^()]*?(?:19|20)\d{2}[a-z]?[^()]*?)\)/g;
      while ((m = par.exec(t))) {
        for (const part of m[1].split(';')) {
          const years = part.match(/(?:19|20)\d{2}[a-z]?/g) || [];
          const sm = part.replace(/^\s*(bkz\.|see|örn\.|e\.g\.,?|aktaran|akt\.|cited in)\s*/i, '').match(/\p{Lu}[\p{L}'’\-]+/u);
          if (sm && years.length && !NOT_SURNAME.has(fold(sm[0]))) years.forEach(y => items.push({ surname: sm[0], year: y.slice(0, 4), key: fold(sm[0]) + '|' + y.slice(0, 4), raw: part.trim(), paragraph: p.id, page: p.page }));
        }
      }
      const nar = /(\p{Lu}[\p{L}'’\-]+)(?:\s+(?:ve|and|&)\s+\p{Lu}[\p{L}'’\-]+|\s+(?:vd\.|et al\.|ve ark\.|ve diğerleri))?\s*\(((?:19|20)\d{2})[a-z]?(?:[,:][^)]*)?\)/gu;
      while ((m = nar.exec(t))) if (!NOT_SURNAME.has(fold(m[1]))) items.push({ surname: m[1], year: m[2], key: fold(m[1]) + '|' + m[2], raw: m[0], paragraph: p.id, page: p.page });
      const num = /\[(\d+(?:\s*[-–,]\s*\d+)*)\]/g;
      while ((m = num.exec(t))) {
        for (const part of m[1].split(',')) {
          const r = part.split(/[-–]/).map(x => +x.trim());
          if (r.length === 2 && r[1] >= r[0] && r[1] - r[0] < 50) for (let k = r[0]; k <= r[1]; k++) numeric.push({ n: k, paragraph: p.id, page: p.page });
          else if (!isNaN(r[0])) numeric.push({ n: r[0], paragraph: p.id, page: p.page });
        }
      }
    }
    const seen = new Set();
    const dedup = items.filter(i => { const k = i.key + '|' + i.paragraph + '|' + i.raw; if (seen.has(k)) return false; seen.add(k); return true; });
    return { authorYear: dedup, numeric };
  }

  function analyze(result) {
    const refs = splitEntries(result.references || []);
    const inText = extractInText(result.paragraphs || []);
    const refKeys = new Map(); refs.forEach(r => { if (r.key) refKeys.set(r.key, r); });
    const refSurYear = r => r.surname && r.year ? fold(r.surname) + '|' + r.year : null;
    const unmatched = [];
    for (const c of inText.authorYear) {
      let r = refKeys.get(c.key);
      if (!r) r = refs.find(x => x.year === c.year && fold(x.text).includes(fold(c.surname)));
      if (r) r.cited = true; else unmatched.push(c);
    }
    const byNum = new Map(refs.filter(r => r.number).map(r => [r.number, r]));
    const unmatchedNum = [];
    for (const c of inText.numeric) { const r = byNum.get(c.n); if (r) r.cited = true; else if (refs.length) unmatchedNum.push(c); }
    const uniqUnmatched = []; const s = new Set();
    for (const u of unmatched) if (!s.has(u.key)) { s.add(u.key); uniqUnmatched.push(u); }
    const keyCount = new Map(); refs.forEach(r => { const k = refSurYear(r); if (k) keyCount.set(k, (keyCount.get(k) || 0) + 1); });
    return {
      references: refs,
      inText: { total: inText.authorYear.length + inText.numeric.length, authorYear: inText.authorYear.length, numeric: inText.numeric.length },
      unmatchedInText: uniqUnmatched,
      unmatchedNumeric: [...new Set(unmatchedNum.map(x => x.n))],
      uncitedRefs: (inText.authorYear.length + inText.numeric.length) ? refs.filter(r => !r.cited) : [],
      noYear: refs.filter(r => !r.year && !r.number),
      duplicates: refs.filter(r => (keyCount.get(refSurYear(r)) || 0) > 1),
      dois: refs.filter(r => r.doi).length,
      note: 'Eşleştirme yazar soyadı + yıl (veya numara) düzeyindedir. Kaynağın metindeki iddiayı gerçekten desteklediği otomatik olarak doğrulanmaz.'
    };
  }

  const jaccard = (a, b) => {
    const A = new Set(fold(a).match(/[a-z0-9]{3,}/g) || []), B = new Set(fold(b).match(/[a-z0-9]{3,}/g) || []);
    if (!A.size || !B.size) return 0; let i = 0; A.forEach(x => B.has(x) && i++); return i / (A.size + B.size - i);
  };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  async function fetchJson(url) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 12000);
    try { const r = await fetch(url, { signal: ctl.signal }); if (r.status === 404) return { notFound: true }; if (!r.ok) return { error: 'HTTP ' + r.status }; return { data: await r.json() }; }
    catch (e) { return { error: e.name === 'AbortError' ? 'zaman aşımı' : 'bağlantı hatası' }; }
    finally { clearTimeout(t); }
  }

  // Yalnızca DOI ve kaynakça metni gönderilir; belge metni gönderilmez.
  async function verify(refs, onProgress, opts = {}) {
    const maxSearch = opts.maxSearch ?? 40;
    let searched = 0;
    for (let i = 0; i < refs.length; i++) {
      const r = refs[i];
      onProgress && onProgress(i + 1, refs.length);
      if (r.doi) {
        const cr = await fetchJson('https://api.crossref.org/works/' + encodeURIComponent(r.doi));
        if (cr.data) {
          const w = cr.data.message || {};
          const y = String(((w.issued || w.published || {})['date-parts'] || [[null]])[0][0] || '');
          const fam = ((w.author || [])[0] || {}).family || '';
          const okYear = !r.year || !y || r.year === y;
          const okAuth = !r.surname || !fam || fold(fam) === fold(r.surname);
          r.verify = { status: okYear && okAuth ? 'verified' : 'mismatch', source: 'Crossref', title: (w.title || [])[0] || '', year: y, author: fam,
            detail: okYear && okAuth ? 'DOI kayıtlı; yazar ve yıl uyumlu.' : `DOI kayıtlı ama bilgiler uyuşmuyor (kayıt: ${fam || '?'}, ${y || '?'}).` };
        } else if (cr.notFound) {
          const dc = await fetchJson('https://api.datacite.org/dois/' + encodeURIComponent(r.doi));
          if (dc.data && dc.data.data) {
            const a = dc.data.data.attributes || {};
            r.verify = { status: 'verified', source: 'DataCite', title: ((a.titles || [])[0] || {}).title || '', year: String(a.publicationYear || ''), detail: 'DOI DataCite kaydında bulundu.' };
          } else if (dc.notFound) r.verify = { status: 'notfound', source: 'Crossref + DataCite', detail: 'DOI hiçbir kayıt kurumunda bulunamadı. Hatalı yazılmış veya uydurma olabilir; manuel kontrol edin.' };
          else r.verify = { status: 'error', detail: 'DataCite sorgusu başarısız: ' + dc.error };
        } else r.verify = { status: 'error', detail: 'Crossref sorgusu başarısız: ' + cr.error };
        await sleep(120);
      } else if (searched < maxSearch && r.text.length > 40) {
        searched++;
        const q = await fetchJson('https://api.crossref.org/works?rows=1&select=DOI,title,issued,author&query.bibliographic=' + encodeURIComponent(r.text.slice(0, 300)));
        const it = q.data && q.data.message && (q.data.message.items || [])[0];
        if (it) {
          const t = (it.title || [])[0] || '';
          const y = String(((it.issued || {})['date-parts'] || [[null]])[0][0] || '');
          const sim = r.title ? jaccard(r.title, t) : jaccard(r.text, t);
          const ok = sim >= 0.6 && (!r.year || r.year === y);
          r.verify = ok ? { status: 'probable', source: 'Crossref arama', title: t, year: y, doi: it.DOI, detail: `DOI'siz kaynak için olası eşleşme (benzerlik ${sim.toFixed(2)}). Manuel teyit önerilir.` }
            : { status: 'unverified', source: 'Crossref arama', detail: 'Crossref kayıtlarında güvenilir eşleşme bulunamadı. Kitap, tez, yerel dergi veya uydurma kaynak olabilir; manuel kontrol edin.' };
        } else r.verify = { status: q.error ? 'error' : 'unverified', detail: q.error ? 'Arama başarısız: ' + q.error : 'Eşleşme bulunamadı.' };
        await sleep(150);
      } else r.verify = { status: 'skipped', detail: 'DOI yok; otomatik arama sınırı aşıldı veya kayıt çok kısa.' };
    }
    return refs;
  }

  return { analyze, verify, splitEntries, extractInText, fold };
});
