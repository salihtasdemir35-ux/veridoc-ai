"""
Katman 3 için model EĞİTİMİ ve DEĞERLENDİRMESİ.

Kullanım:
  python train.py --data veri.csv --base dbmdz/bert-base-turkish-cased --out models/tr-detector
  python train.py --data veri.csv --base xlm-roberta-base --out models/xlmr-detector --epochs 3

Veri (CSV, UTF-8) sütunları:
  text    : paragraf metni
  label   : human | ai_edited | ai_generated
  doc_id  : metnin geldiği belge/yazar kimliği  (VERİ SIZINTISINI önlemek için ZORUNLU)
  lang    : tr | en   (dil bazlı ayrı raporlama için)

Yöntem:
  - Eğitim / doğrulama / test bölmesi doc_id düzeyinde yapılır (GroupShuffleSplit).
    Aynı belgenin parçaları asla iki kümeye birden düşmez; betik bunu assert ile doğrular.
  - Doğrulama kümesinde sıcaklık ölçekleme (temperature scaling) ile kalibrasyon.
  - Test kümesinde: accuracy, makro precision/recall/F1, ROC-AUC (AI vs insan),
    ECE (kalibrasyon hatası), insan metinlerinde yanlış pozitif oranı, dil bazlı metrikler.
Çıktılar: model, tokenizer, labels.json, calibration.json, metrics.json
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score, confusion_matrix, precision_recall_fscore_support, roc_auc_score
from sklearn.model_selection import GroupShuffleSplit
from torch.utils.data import DataLoader
from transformers import AutoModelForSequenceClassification, AutoTokenizer, get_linear_schedule_with_warmup

LABELS = ["human", "ai_edited", "ai_generated"]


def split(df, seed):
    g1 = GroupShuffleSplit(n_splits=1, test_size=0.30, random_state=seed)
    tr_idx, rest_idx = next(g1.split(df, groups=df.doc_id))
    train, rest = df.iloc[tr_idx], df.iloc[rest_idx]
    g2 = GroupShuffleSplit(n_splits=1, test_size=0.50, random_state=seed)
    va_idx, te_idx = next(g2.split(rest, groups=rest.doc_id))
    val, test = rest.iloc[va_idx], rest.iloc[te_idx]
    a, b, c = set(train.doc_id), set(val.doc_id), set(test.doc_id)
    assert not (a & b or a & c or b & c), "Veri sızıntısı: aynı doc_id birden fazla kümede!"
    return train, val, test


def batches(tok, df, bs, shuffle):
    data = list(zip(df.text.tolist(), df.y.tolist()))

    def collate(b):
        enc = tok([x for x, _ in b], truncation=True, max_length=512, padding=True, return_tensors="pt")
        enc["labels"] = torch.tensor([y for _, y in b])
        return enc
    return DataLoader(data, batch_size=bs, shuffle=shuffle, collate_fn=collate)


@torch.no_grad()
def logits_of(model, loader, device):
    model.eval()
    out, ys = [], []
    for b in loader:
        ys.append(b.pop("labels"))
        out.append(model(**{k: v.to(device) for k, v in b.items()}).logits.cpu())
    return torch.cat(out), torch.cat(ys)


def fit_temperature(logits, y):
    t = torch.nn.Parameter(torch.ones(1))
    opt = torch.optim.LBFGS([t], lr=0.05, max_iter=200)
    nll = torch.nn.CrossEntropyLoss()

    def closure():
        opt.zero_grad()
        loss = nll(logits / t.clamp(min=0.05), y)
        loss.backward()
        return loss
    opt.step(closure)
    return float(t.clamp(min=0.05).item())


def ece(probs, y, bins=10):
    conf = probs.max(1)
    pred = probs.argmax(1)
    acc = (pred == y).astype(float)
    e = 0.0
    edges = np.linspace(0, 1, bins + 1)
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.any():
            e += m.mean() * abs(acc[m].mean() - conf[m].mean())
    return float(e)


def metrics(probs, y):
    pred = probs.argmax(1)
    p, r, f, _ = precision_recall_fscore_support(y, pred, average="macro", zero_division=0)
    per = precision_recall_fscore_support(y, pred, labels=[0, 1, 2], zero_division=0)
    is_ai = (y != 0).astype(int)
    ai_score = probs[:, 2] + 0.5 * probs[:, 1]
    try:
        auc = float(roc_auc_score(is_ai, ai_score))
    except ValueError:
        auc = None
    human = y == 0
    fpr = float((pred[human] != 0).mean()) if human.any() else None
    return {
        "n": int(len(y)),
        "accuracy": round(float(accuracy_score(y, pred)), 4),
        "precision_macro": round(float(p), 4), "recall_macro": round(float(r), 4), "f1_macro": round(float(f), 4),
        "per_class": {LABELS[i]: {"precision": round(float(per[0][i]), 4), "recall": round(float(per[1][i]), 4),
                                  "f1": round(float(per[2][i]), 4), "support": int(per[3][i])} for i in range(3)},
        "roc_auc": round(auc, 4) if auc is not None else None,
        "ece": round(ece(probs, y), 4),
        "human_fpr": round(fpr, 4) if fpr is not None else None,
        "confusion_matrix": confusion_matrix(y, pred, labels=[0, 1, 2]).tolist(),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--base", default="xlm-roberta-base")
    ap.add_argument("--out", required=True)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()

    torch.manual_seed(a.seed)
    df = pd.read_csv(a.data).dropna(subset=["text", "label", "doc_id"])
    df = df[df.label.isin(LABELS)].copy()
    if "lang" not in df:
        df["lang"] = "unk"
    df["y"] = df.label.map(LABELS.index)
    train, val, test = split(df, a.seed)
    print(f"Eğitim {len(train)} | Doğrulama {len(val)} | Test {len(test)} paragraf "
          f"({train.doc_id.nunique()}/{val.doc_id.nunique()}/{test.doc_id.nunique()} belge)")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    tok = AutoTokenizer.from_pretrained(a.base)
    model = AutoModelForSequenceClassification.from_pretrained(
        a.base, num_labels=3, id2label=dict(enumerate(LABELS)), label2id={l: i for i, l in enumerate(LABELS)}).to(device)
    tl = batches(tok, train, a.bs, True)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.01)
    steps = len(tl) * a.epochs
    sch = get_linear_schedule_with_warmup(opt, int(0.06 * steps), steps)
    for ep in range(a.epochs):
        model.train()
        tot = 0.0
        for b in tl:
            b = {k: v.to(device) for k, v in b.items()}
            loss = model(**b).loss
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); sch.step(); opt.zero_grad()
            tot += loss.item()
        print(f"epoch {ep + 1}: loss {tot / max(1, len(tl)):.4f}")

    vl, vy = logits_of(model, batches(tok, val, a.bs, False), device)
    T = fit_temperature(vl, vy)
    tl_, ty = logits_of(model, batches(tok, test, a.bs, False), device)
    raw = torch.softmax(tl_, -1).numpy()
    cal = torch.softmax(tl_ / T, -1).numpy()
    yt = ty.numpy()
    res = metrics(cal, yt)
    res["ece_uncalibrated"] = round(ece(raw, yt), 4)
    res["temperature"] = round(T, 4)
    res["by_language"] = {}
    for lang in sorted(test.lang.unique()):
        m = (test.lang == lang).values
        if m.sum() >= 10:
            res["by_language"][lang] = metrics(cal[m], yt[m])
    res["split"] = {"train_docs": int(train.doc_id.nunique()), "val_docs": int(val.doc_id.nunique()),
                    "test_docs": int(test.doc_id.nunique()), "group_split": True}
    res["base_model"] = a.base

    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(out); tok.save_pretrained(out)
    (out / "labels.json").write_text(json.dumps(LABELS))
    (out / "calibration.json").write_text(json.dumps({"temperature": T}))
    (out / "metrics.json").write_text(json.dumps(res, ensure_ascii=False, indent=2))
    print(json.dumps({k: res[k] for k in ("accuracy", "f1_macro", "roc_auc", "ece", "human_fpr")}, indent=2))
    print(f"Model kaydedildi: {out}  ->  DETECTOR_MODEL={out}")


if __name__ == "__main__":
    main()
