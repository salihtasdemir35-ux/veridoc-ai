"""
Katman 4 — İsteğe bağlı LLM destekli akademik değerlendirme (Anthropic Claude API).

Ortam değişkenleri:
  ANTHROPIC_API_KEY : Sunucu tarafında tutulur; ön yüze ASLA gönderilmez.
  LLM_MODEL         : Varsayılan claude-sonnet-5-5
  LLM_MAX_PARAGRAPHS: Bir analizde gönderilecek en fazla paragraf (varsayılan 30)

Bu katmanın çıktısı açıklayıcıdır; birleşik puana katılmaz.
"""
from __future__ import annotations

import json
import os
import re

import httpx

SYSTEM = """Sen akademik yayıncılık etiği ve stilometri konusunda deneyimli bir değerlendiricisin.
Sana bir akademik belgeden paragraflar verilecek. Her paragraf için:
- dilsel yapıyı ve AI yazım karakteristiklerini incele,
- insan yazımıyla uyumlu özellikleri de mutlaka belirt,
- akademik anlatım kalitesini kısaca değerlendir.
KESİN HÜKÜM VERME. "AI tarafından yazılmıştır" deme; "AI yazım karakteristikleriyle uyumlu göstergeler" gibi temkinli ifadeler kullan.
Düzgün dil bilgisi, standart akademik kalıplar ve uzun cümleler tek başına AI kanıtı değildir.
Kategori önerisi şu seçeneklerden biri olmalı: "İnsan ağırlıklı", "İnsan + AI dil düzenlemesi", "Karma", "AI üretimiyle uyumlu güçlü göstergeler", "Sonuçlandırılamaz".
Yalnızca geçerli JSON döndür, başka metin ekleme."""


def _extract_json(text: str):
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}|\[.*\]", text, flags=re.S)
        if not m:
            raise
        return json.loads(m.group(0))


class LLMReviewer:
    def __init__(self, key: str | None, model: str, max_paragraphs: int):
        self.key = key
        self.model = model
        self.max_paragraphs = max_paragraphs
        self.available = bool(key)

    @classmethod
    def from_env(cls):
        return cls(os.getenv("ANTHROPIC_API_KEY") or None, os.getenv("LLM_MODEL", "claude-sonnet-5-5"),
                   int(os.getenv("LLM_MAX_PARAGRAPHS", "30")))

    def info(self):
        return {"available": self.available, "model": self.model if self.available else None, "max_paragraphs": self.max_paragraphs}

    def _call(self, user: str, max_tokens: int = 4000) -> str:
        r = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": self.model, "max_tokens": max_tokens, "system": SYSTEM,
                  "messages": [{"role": "user", "content": user}]},
            timeout=180,
        )
        r.raise_for_status()
        return "".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text")

    def review(self, paragraphs, language: str, context: dict):
        lang_note = "Yanıtı Türkçe yaz." if language == "tr" else "Yanıtı Türkçe yaz (metin İngilizce olsa da)."
        results = []
        for i in range(0, len(paragraphs), 5):
            batch = paragraphs[i:i + 5]
            payload = [{"id": p["id"], "section": p.get("section"), "page": p.get("page"), "text": p["text"]} for p in batch]
            user = (f"{lang_note}\nParagraflar (JSON):\n{json.dumps(payload, ensure_ascii=False)}\n\n"
                    'Şu biçimde yanıt ver: {"results":[{"id":"...","assessment":"2-4 cümle","ai_features":["..."],'
                    '"human_features":["..."],"category_suggestion":"..."}]}')
            data = _extract_json(self._call(user))
            results.extend(data.get("results", []) if isinstance(data, dict) else data)
        summary_in = {
            "belge": context,
            "paragraf_degerlendirmeleri": [{"id": r.get("id"), "kategori": r.get("category_suggestion"),
                                            "ozet": r.get("assessment")} for r in results],
        }
        summary_user = (f"{lang_note}\nAşağıdaki bilgiler bir akademik belgenin en şüpheli paragraflarının değerlendirmesidir.\n"
                        f"{json.dumps(summary_in, ensure_ascii=False)}\n\n"
                        'Belgenin genel yazım karakteristiği, AI destekli düzenleme ile AI üretimi ayrımı ve manuel inceleme '
                        'önerileri hakkında temkinli, 1 paragraflık bir uzman değerlendirmesi yaz. '
                        'Şu biçimde yanıt ver: {"summary":"..."}')
        try:
            summary = _extract_json(self._call(summary_user, 1500)).get("summary")
        except Exception:  # noqa: BLE001
            summary = None
        return {"model": self.model, "results": results, "summary": summary}
