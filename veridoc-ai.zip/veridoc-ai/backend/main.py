"""
VERIDOC AI — Arka uç (FastAPI)

- Ön yüzü http://localhost:8000 adresinden sunar.
- Katman 3: /api/classify   (eğitilmiş model yapılandırılmışsa)
- Katman 4: /api/llm-review (ANTHROPIC_API_KEY yapılandırılmışsa ve kullanıcı onay verdiyse)

Belgeler diske yazılmaz; istekler bellekte işlenir.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field


def _load_env():
    """Basit .env okuyucu (ek bağımlılık gerektirmez)."""
    env = Path(__file__).resolve().parent / ".env"
    if env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


_load_env()

from classifier import Classifier  # noqa: E402
from llm import LLMReviewer  # noqa: E402

app = FastAPI(title="VeriDoc AI API", version="1.0.0")

# Yerel kullanım içindir. Sunucuya kurulacaksa ALLOWED_ORIGINS ile daraltın.
origins = [o.strip() for o in os.getenv("ALLOWED_ORIGINS", "*").split(",") if o.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET", "POST"], allow_headers=["*"])

classifier = Classifier.from_env()
reviewer = LLMReviewer.from_env()

MAX_PARAS = 400
MAX_CHARS = 6000


class Para(BaseModel):
    id: str
    text: str = Field(max_length=MAX_CHARS * 2)
    lang: Optional[str] = None
    section: Optional[str] = None
    page: Optional[int] = None
    heuristic: Optional[int] = None


class ClassifyReq(BaseModel):
    paragraphs: List[Para]


class ReviewReq(BaseModel):
    consent: bool
    language: str = "tr"
    paragraphs: List[Para]
    context: dict = {}


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "classifier": classifier.info(),
        "llm": reviewer.info(),
    }


@app.post("/api/classify")
def classify(req: ClassifyReq):
    if not classifier.available:
        raise HTTPException(503, "Eğitilmiş model yapılandırılmadı (DETECTOR_MODEL).")
    paras = req.paragraphs[:MAX_PARAS]
    results = classifier.predict([p.text[:MAX_CHARS] for p in paras])
    return {"results": [{"id": p.id, **r} for p, r in zip(paras, results)]}


@app.post("/api/llm-review")
def llm_review(req: ReviewReq):
    if not req.consent:
        raise HTTPException(400, "Harici AI servisine gönderim için kullanıcı onayı gerekli.")
    if not reviewer.available:
        raise HTTPException(503, "LLM servisi yapılandırılmadı (ANTHROPIC_API_KEY).")
    paras = req.paragraphs[: reviewer.max_paragraphs]
    try:
        return reviewer.review([p.model_dump() for p in paras], req.language, req.context)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, f"LLM servisi hatası: {e}") from e


FRONTEND = Path(__file__).resolve().parent.parent / "frontend"
if FRONTEND.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND), html=True), name="frontend")
