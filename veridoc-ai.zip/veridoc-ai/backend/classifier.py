"""
Katman 3 — Eğitilmiş AI metin sınıflandırıcı.

Ortam değişkenleri:
  DETECTOR_MODEL     : train.py çıktısı klasör ya da HuggingFace model kimliği. Boşsa katman KAPALI.
  DETECTOR_AI_LABEL  : (2 sınıflı dış modeller için) AI sınıfının etiket adı/indeksi. Varsayılan: 1
  DETECTOR_DEVICE    : cpu | cuda (varsayılan: otomatik)

Sahte model YOKTUR: model yapılandırılmamışsa available=False döner ve ön yüz bu katmanı
"bağlı değil" olarak gösterir.

train.py ile eğitilmiş klasörde:
  calibration.json -> {"temperature": T}
  metrics.json     -> test kümesi metrikleri (precision, recall, F1, ROC-AUC, ECE, insan FPR, dil bazlı)
  labels.json      -> ["human", "ai_edited", "ai_generated"]
"""
from __future__ import annotations

import json
import os
from pathlib import Path


class Classifier:
    def __init__(self, model_id: str | None):
        self.model_id = model_id
        self.available = False
        self.error = None
        self.temperature = 1.0
        self.calibrated = False
        self.metrics = None
        self.labels = None
        if not model_id:
            return
        try:
            import torch  # noqa: F401
            from transformers import AutoModelForSequenceClassification, AutoTokenizer
        except ImportError:
            self.error = "torch/transformers kurulu değil (pip install -r requirements-ml.txt)"
            return
        try:
            import torch
            self.torch = torch
            self.device = os.getenv("DETECTOR_DEVICE") or ("cuda" if torch.cuda.is_available() else "cpu")
            self.tok = AutoTokenizer.from_pretrained(model_id)
            self.model = AutoModelForSequenceClassification.from_pretrained(model_id).to(self.device).eval()
            p = Path(model_id)
            if p.is_dir():
                if (p / "calibration.json").exists():
                    self.temperature = float(json.loads((p / "calibration.json").read_text())["temperature"])
                    self.calibrated = True
                if (p / "metrics.json").exists():
                    self.metrics = json.loads((p / "metrics.json").read_text())
                if (p / "labels.json").exists():
                    self.labels = json.loads((p / "labels.json").read_text())
            if not self.labels:
                id2label = self.model.config.id2label or {}
                self.labels = [str(id2label.get(i, i)).lower() for i in range(self.model.config.num_labels)]
            self.available = True
        except Exception as e:  # noqa: BLE001
            self.error = str(e)

    @classmethod
    def from_env(cls):
        return cls(os.getenv("DETECTOR_MODEL") or None)

    def info(self):
        m = self.metrics or {}
        return {
            "available": self.available,
            "model": self.model_id,
            "calibrated": self.calibrated,
            "labels": self.labels,
            "error": self.error,
            "metrics": {k: m.get(k) for k in ("f1_macro", "roc_auc", "human_fpr", "ece", "accuracy")} if m else None,
        }

    def _ai_index(self):
        env = os.getenv("DETECTOR_AI_LABEL", "1")
        if env.isdigit():
            return int(env)
        return self.labels.index(env.lower())

    def predict(self, texts, batch_size: int = 8):
        torch = self.torch
        out = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            enc = self.tok(batch, truncation=True, max_length=512, padding=True, return_tensors="pt").to(self.device)
            with torch.no_grad():
                logits = self.model(**enc).logits / self.temperature
                probs = torch.softmax(logits, dim=-1).cpu().tolist()
            for pr in probs:
                if self.labels and set(self.labels) >= {"human", "ai_edited", "ai_generated"}:
                    d = {l: round(p, 4) for l, p in zip(self.labels, pr)}
                    ai_score = d["ai_generated"] + 0.5 * d["ai_edited"]
                    out.append({"ai_score": round(ai_score, 4), "probs": d, "calibrated": self.calibrated, "model": self.model_id})
                else:
                    ai = pr[self._ai_index()]
                    out.append({"ai_score": round(ai, 4), "probs": {"human": round(1 - ai, 4), "ai_generated": round(ai, 4)},
                                "calibrated": self.calibrated, "model": self.model_id})
        return out
