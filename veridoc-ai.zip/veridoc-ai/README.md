# VeriDoc AI

**Akademik Belgeler İçin Yapay Zekâ Kullanım Analizi** (Android uygulaması + masaüstü/web) — Word (.docx) ve PDF belgelerinde paragraf düzeyinde AI yazım göstergesi, üslup değişimi ve kaynakça kontrolü.

> Bu uygulama kesin AI tespiti yapmaz. Ürettiği değer, metnin AI yazım karakteristikleriyle ne ölçüde örtüştüğünü gösteren **kalibre edilmemiş bir göstergedir**; gerçek AI kullanım oranı veya yazarlık olasılığı değildir.

## Hızlı başlangıç

**Windows:** `start.bat` dosyasına çift tıklayın. Tarayıcıda `http://localhost:8000` açılır.
**macOS / Linux:** `./start.sh`

Gereken tek şey Python 3.10+ ve internet bağlantısıdır (kütüphaneler CDN’den yüklenir; OCR dil verisi ilk kullanımda indirilir).

Sunucu kurmadan da çalışır: `frontend/index.html` dosyasını tarayıcıda açarsanız Katman 1, Katman 2 ve kaynakça kontrolü çalışır. Katman 3 ve 4 sunucu gerektirir.

## Mimari

```
frontend/               Tarayıcıda çalışır, belge yerel olarak işlenir
  index.html            Arayüz
  js/parser.js          DOCX (mammoth.js), PDF (pdf.js), taranmış PDF için OCR (tesseract.js)
  js/analyzer.js        Katman 1 (dilsel/istatistiksel) + Katman 2 (stilometri) + birleştirme
  js/citations.js       Atıf–kaynakça eşleştirme, Crossref/DataCite DOI doğrulaması
  js/app.js             Arayüz, grafikler (Chart.js), Excel (SheetJS), yazdır/PDF
backend/                Python FastAPI
  main.py               /api/health, /api/classify, /api/llm-review; ön yüzü sunar
  classifier.py         Katman 3: eğitilmiş model yükleyici (yoksa kapalı kalır)
  train.py              Katman 3 için eğitim + değerlendirme betiği
  llm.py                Katman 4: isteğe bağlı Claude API değerlendirmesi
tests/test_analyzer.js  node tests/test_analyzer.js
```

## Analiz katmanları

| Katman | Durum | Açıklama |
|---|---|---|
| 1. Dilsel ve istatistiksel | Her zaman çalışır | Cümle uzunluğu ve değişkenliği, TTR, MTLD, bağlaç yoğunluğu, AI kalıp ifadeleri (TR/EN), cümle başlangıç çeşitliliği, somutluk (sayı/atıf/özel ad), tekrar, karakter 3-gram tahmin edilebilirliği. Ağırlıklar: düzenli cümle 0,25 · kalıp ifade 0,25 · bağlaç 0,15 · tekdüze başlangıç 0,10 · somutluk eksikliği 0,25. Deneyim/birinci şahıs ifadeleri puanı düşürür. |
| 2. Stilometri | Her zaman çalışır | 9 üslup özelliği belge içinde z-puanına çevrilir; her paragraf önceki 3 paragrafla ve belge ortalamasıyla karşılaştırılır. Türkçe ve İngilizce paragraflar ayrı gruplanır. Puana katılmaz, ayrı raporlanır. |
| 3. Eğitilmiş model | Model yapılandırılırsa | Sahte model yoktur. `DETECTOR_MODEL` boşsa katman “bağlı değil” görünür ve yerine başka puan gösterilmez. |
| 4. LLM değerlendirmesi | API anahtarı + kullanıcı onayı | Açıklayıcı yorum üretir; **puana katılmaz**. |

**Birleştirme:** model yoksa birleşik gösterge = sezgisel puan; model varsa 0,5 × sezgisel + 0,5 × model. Katmanlar 45 puan veya daha fazla çelişirse paragraf “sonuçlandırılamayan” olur.

**Kategoriler:** İnsan ağırlıklı · İnsan + AI dil düzenlemesi (yüzey cilası yüksek, içerik somut) · Karma · Güçlü AI göstergeleri (yüksek gösterge ve somutluk eksikliği) · Sonuçlandırılamayan (40 kelime altı, tek cümle, zayıf ya da çelişen göstergeler).

## Katman 3: modeli eğitmek

Hazır bir “Türkçe akademik AI dedektörü” varsayılmaz; kendi etiketli verinizle eğitip ölçmeniz gerekir.

1. CSV hazırlayın: `text,label,doc_id,lang` — `label` ∈ `human`, `ai_edited`, `ai_generated`. `doc_id` zorunludur: aynı belgenin parçaları farklı kümelere düşmez.
2. `pip install -r backend/requirements-ml.txt`
3. `cd backend && python train.py --data veri.csv --base dbmdz/bert-base-turkish-cased --out models/tr-detector` (çok dilli için `--base xlm-roberta-base`)
4. Betik `metrics.json` içine accuracy, makro precision/recall/F1, ROC-AUC, ECE (kalibrasyon öncesi/sonrası), **insan metinlerinde yanlış pozitif oranı** ve dil bazlı metrikleri yazar. Sıcaklık ölçekleme ile kalibre eder.
5. `backend/.env` içine `DETECTOR_MODEL=models/tr-detector` yazıp `start.bat`’ı yeniden çalıştırın.

Hazır bir HuggingFace modeli de kullanılabilir (`DETECTOR_MODEL=<model-kimliği>`, gerekirse `DETECTOR_AI_LABEL`); ancak o modelin Türkçe akademik metinlerdeki performansını kendi test verinizle ölçmeden sonuçlarına güvenmeyin.

## Katman 4: LLM değerlendirmesi

`backend/.env.example` dosyasını `backend/.env` olarak kopyalayın ve `ANTHROPIC_API_KEY` değerini girin. Anahtar yalnızca sunucuda kalır, ön yüz koduna yazılmaz. Arayüzde onay kutusu işaretlenmeden hiçbir paragraf gönderilmez. `.env` dosyasını GitHub’a yüklemeyin (`.gitignore` bunu engeller).

## Gizlilik

Belgeler tarayıcıda işlenir; sunucu da dosya kaydetmez. DOI doğrulamasında yalnızca DOI’ler ve kaynakça satırları Crossref/DataCite’a gönderilir, kullanıcı butona bastığında.

## Sınırlılıklar

- Katman 1–2 eşik ve ağırlıkları uzman sezgisine dayanır; etiketli veriyle doğrulanmamıştır.
- Düzgün dil bilgisi, standart akademik kalıplar ve uzun cümleler AI kanıtı değildir; insan metinleri yanlışlıkla işaretlenebilir.
- Word belgelerinde sayfa numarası tahminidir (~330 kelime/sayfa). Çok sütunlu PDF’lerde paragraf sırası bozulabilir.
- Kaynak doğrulaması Crossref ve DataCite ile sınırlıdır; kitaplar ve bazı ulusal dergiler bulunmayabilir.

## Android uygulaması (APK)

- Uygulama adı: **VeriDoc AI** · paket adı: `com.veridoc.ai` · Capacitor 7, Android 6.0 ve üzeri.
- Tüm kütüphaneler ve yazı tipleri uygulamanın içindedir; analiz internetsiz çalışır. Yalnızca taranmış PDF için OCR (ilk kullanımda) ve DOI doğrulaması internet ister.
- Excel ve PDF raporları Android paylaşım menüsüyle kaydedilir (Dosyalar, Drive, e-posta…).
- Telefonda eğitilmiş model ve LLM katmanları yoktur; sayfanın altındaki “Analiz sunucusu ayarı” ile aynı ağdaki bir bilgisayarda çalışan sunucunun adresi (ör. `http://192.168.1.20:8000`) girilebilir. Bunun için sunucuyu `--host 0.0.0.0` ile başlatın.
- APK, GitHub Actions ile `.github/workflows/build-apk.yml` tarafından otomatik derlenir; simge ve açılış ekranı `assets/` klasöründen üretilir.

## GitHub’a yükleme ve APK alma

1. github.com’da **+** → **New repository** → ad: `veridoc-ai` → **Public** → **Create repository**.
2. Zip dosyasını bilgisayarınızda açın. `veridoc-ai` klasörünün içinde `.github`, `assets`, `backend`, `frontend`, `scripts`, `tests`, `package.json`, `capacitor.config.json` görünmeli.
3. Depo sayfasında **uploading an existing file** bağlantısına tıklayın.
4. `veridoc-ai` klasörünün **içindeki her şeyi** seçip sayfaya sürükleyin (zip’in kendisini değil). `.github` klasörünün listede göründüğünü kontrol edin.
5. **Commit changes**.
6. **Actions** sekmesi → “APK oluştur” çalışması başlar (8–12 dakika). Yeşil tik çıkınca bitmiştir.
7. APK’yı alın: sağ taraftaki **Releases** → en üstteki sürüm → **VeriDoc-AI.apk**. (Alternatif: Actions → çalışma → en alttaki **Artifacts** → VeriDoc-AI-APK.)
8. Telefonda APK’yı açın; “bilinmeyen kaynaklardan yükleme” izni istenirse verin.

`.github` klasörü yüklenmezse: **Add file → Create new file**, ad kutusuna `.github/workflows/build-apk.yml` yazın, bu dosyanın içeriğini yapıştırıp **Commit changes** deyin.

Güncelleme yaparken değişen dosyaları aynı şekilde yükleyin; her yüklemede yeni APK otomatik oluşur.
