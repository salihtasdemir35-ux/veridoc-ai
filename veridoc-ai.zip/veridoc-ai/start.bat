@echo off
chcp 65001 >nul
cd /d %~dp0
echo VeriDoc AI baslatiliyor...
if not exist .venv (
  py -3 -m venv .venv 2>nul || python -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install -q --upgrade pip
python -m pip install -q -r backend\requirements.txt
start "" cmd /c "timeout /t 4 >nul & start http://localhost:8000"
cd backend
python -m uvicorn main:app --host 127.0.0.1 --port 8000
pause
